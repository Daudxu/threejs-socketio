(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Info = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgpCHIAAhBIBJAAIAABBgAgnA0IAAgHQAAgSAEgLQAEgLAIgIQAIgJAagWQAPgMAAgKQAAgKgGgGQgGgFgMAAQgMAAgIAIQgJAJgBAVIhHgJQAEgmAYgYQAZgYAyAAQAmAAAZARQAhAWAAAlQAAAPgJAPQgIAOgbAUQgSAOgEAJQgFAJAAAOg");
	this.shape.setTransform(253.95,76.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAbBiIAAhpQABgSgHgHQgGgIgNAAQgMAAgJALQgHAJgBAaIAABcIhKAAIAAi/IBFAAIAAAfQAPgTAQgIQAPgIAWAAQAfAAASASQARASAAAmIAAB5g");
	this.shape_1.setTransform(218.05,80.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgkCEIAAi+IBJAAIAAC+gAgkhSIAAgxIBJAAIAAAxg");
	this.shape_2.setTransform(199.575,76.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhcBUQgSgQAAgXQAAgWAOgOQAMgNAjgHIA0gLIAbgJQgBgOgFgFQgGgGgOAAQgRAAgJAGQgHAFgEAMIhHgHQAEgTAIgKQAHgLAPgIQAKgFASgDQARgDAUAAQAhAAAUADQAUAEANAMQAJAIAGAPQAFAPAAANIAABUQABANABAIQACAIAFAMIhFAAIgFgLIgDgNQgOAOgOAGQgTAIgaAAQghAAgTgQgAgBAOQgWAGgHAGQgFAGAAAIQAAAIAFAGQAHAFALAAQAMAAAKgGQALgGAEgIQAEgJABgOIAAgLg");
	this.shape_3.setTransform(181.1,80.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhOB4QgVgSAAgdIAAgKIBHAIQADALAGADQAIAGALAAQAQAAAIgJQAIgIAAgWIAAgcQgLANgLAFQgQAJgUAAQgmAAgYgiQgRgWAAgoQAAgsAWgXQAWgYAjAAQAWAAAOAIQAOAHANASIAAgdIBFAAIAAC1IAAAIQAAASgIAQQgHARgNAJQgNALgTAEQgUAFgZAAQg5AAgWgRgAgXhJQgIALAAAXQAAAVAJAKQAIAJAOAAQAOAAAJgKQAJgKAAgUQAAgWgJgLQgKgLgNAAQgOAAgJAKg");
	this.shape_4.setTransform(155.975,83.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AA6CEIgNgrIhcAAIgNArIhTAAIBjkHIBZAAIBjEHgAAcAfIgchdIgdBdIA5AAg");
	this.shape_5.setTransform(129.825,76.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhgCCIgGgzQAQAFAUABQANAAAIgHQAIgGAFgPIhQi/IBNAAIAnCAIAliAIBIAAIhMDMQgNAjgNANQgTARgnAAQgQAAghgFg");
	this.shape_6.setTransform(91.875,84.15);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhcBUQgSgQAAgXQAAgWAOgOQAMgNAjgHIA0gLIAagJQAAgOgFgFQgGgGgOAAQgRAAgJAGQgHAFgEAMIhHgHQAEgTAIgKQAHgLAPgIQAKgFASgDQARgDAUAAQAhAAAUADQAUAEANAMQAJAIAGAPQAFAPAAANIAABUQABANABAIQACAIAFAMIhFAAIgFgLIgDgNQgOAOgOAGQgTAIgaAAQghAAgTgQgAgBAOQgXAGgGAGQgFAGAAAIQAAAIAFAGQAHAFALAAQAMAAAKgGQALgGAEgIQAEgJAAgOIAAgLg");
	this.shape_7.setTransform(68.15,80.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgkCEIAAkHIBJAAIAAEHg");
	this.shape_8.setTransform(49.675,76.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhwCEIAAkHICIAAQAsgBAXAWQAVAVAAAnQAAAogYAWQgYAWgyAAIgrAAIAABigAgdgTIAUAAQAXAAAJgHQAKgJAAgNQAAgMgJgJQgIgIgWAAIgXAAg");
	this.shape_9.setTransform(30.7,76.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FF0000").s().p("AhKBiIAAi/IBFAAIAAAgQAIgVALgHQAKgIAQAAQAQAAAUAKIgYA1QgMgGgIAAQgOAAgJAMQgJARgBAsIAABBg");
	this.shape_10.setTransform(246.4,37.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FF0000").s().p("Ag8BZQgWgKgOgYQgOgXAAggQAAgsAdgcQAdgbAyAAQAoAAAZAMQAXAMANAYQAMAYAAAlIAAAIIiSAAQACASAIAIQAKANAQAAQALAAAKgGQAGgDAHgJIBIAHQgRAdgXANQgYAMgrAAQglAAgXgLgAAlgQQgCgVgKgKQgKgJgOAAQgRAAgKAOQgHAJgCARIBIAAIAAAAg");
	this.shape_11.setTransform(224.3,38.125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FF0000").s().p("AggBgIhQi/IBMAAIAlB5IAmh5IBKAAIhRC/g");
	this.shape_12.setTransform(200.675,38.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FF0000").s().p("AhGB7QgegPgSgeQgSgfAAgvQAAg/AkglQAkgkBAAAQBCAAAkAjQAjAkAABAQAAAtgQAfQgPAdgeARQgdAQgsAAQgsAAgdgOgAgog4QgOARAAAnQAAAoAOASQAPASAZAAQAbAAAOgRQAPgRAAgsQgBglgPgRQgPgSgZAAQgZAAgPASg");
	this.shape_13.setTransform(173.9,34.45);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FF0000").s().p("Ag8BZQgWgKgOgYQgOgXAAggQAAgsAdgcQAcgbA0AAQAoAAAYAMQAYAMAMAYQAMAYAAAlIAAAIIiSAAQACASAIAIQAKANAQAAQALAAAKgGQAGgDAHgJIBIAHQgQAdgYANQgYAMgrAAQglAAgXgLgAAlgQQgCgVgKgKQgKgJgOAAQgRAAgKAOQgHAJgCARIBIAAIAAAAg");
	this.shape_14.setTransform(133.95,38.125);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FF0000").s().p("ABZBiIAAhtQAAgMgFgHQgIgKgLAAQgMAAgIAKQgIAJAAAVIAABiIhJAAIAAhoIgCgSQgCgHgGgEQgFgFgIAAQgNAAgIAJQgIAKAAAVIAABiIhKAAIAAi/IBFAAIAAAcQAOgSAQgHQAPgHAVAAQAXAAAMAIQAOAIAIAQQASgTAOgHQAOgGAVAAQAfAAARASQASATAAAmIAAB4g");
	this.shape_15.setTransform(103.125,37.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FF0000").s().p("AhcBUQgRgQAAgXQgBgWANgOQAOgNAigHIA1gLIAagJQAAgOgGgFQgGgGgOAAQgRAAgJAGQgHAFgFAMIhFgHQAEgTAHgKQAHgLAOgIQALgFARgDQASgDAVAAQAgAAAUADQAUAEANAMQAJAIAGAPQAGAPAAANIAABUQAAANABAIQACAIAGAMIhFAAIgGgLIgDgNQgOAOgOAGQgSAIgaAAQgjAAgSgQgAgBAOQgXAGgFAGQgHAGAAAIQAAAIAHAGQAFAFAMAAQAMAAAKgGQAKgGAFgIQAFgJAAgOIAAgLg");
	this.shape_16.setTransform(72.25,38.125);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FF0000").s().p("AhHB5QgegQgQggQgRgfAAgqQAAgqASggQASggAjgRQAagNAtAAQAsAAAWAIQAVAIAPARQAOAQAHAaIhPAOQgEgPgMgIQgMgHgSAAQgaAAgQASQgQASAAApQAAAqARASQAQATAbAAQAOAAANgEQAMgEAQgKIAAgZIg3AAIAAg2IB/AAIAABxQgkAYgcAJQgcAJgmAAQgvAAgdgQg");
	this.shape_17.setTransform(44.275,34.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_1
	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#CCCCCC").s().p("AzDJsQjIAAAAjIIAAtHQAAjIDIAAMAmHAAAQDIAAAADIIAANHQAADIjIAAg");
	this.shape_18.setTransform(142,62);

	this.timeline.addTween(cjs.Tween.get(this.shape_18).wait(1));

}).prototype = getMCSymbolPrototype(lib.Info, new cjs.Rectangle(-18.9,0,319.9,124), null);


(lib.Bat = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0033FF").s().p("AmFCWQg+AAgsgsQgsgsAAg+QAAg9AsgsQAsgsA+AAIMLAAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAg");
	this.shape.setTransform(0.55,-0.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Bat, new cjs.Rectangle(-53.4,-15.9,108,30), null);


(lib.Ball = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(4,1,1).p("AjcCUQgWiUBDgtQBUg3BiBiQBcBbBMgrQA+gcgNil");
	this.shape.setTransform(-0.0835,1.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#009933").s().p("Ai+C4QgSgRgMgSQgGgkAAgfQAAhbAzgjIACgCIAAAAQAdgSAfAAIAAAAIAAAAQA4AAA9A9IACABQA/A+A3AAIAAAAIAAAAQAZAAAXgMIABgBIACAAQAygYAAhzQAAgZgCgeQACAeAAAZQAABzgyAYIgCAAIgBABQgXAMgZAAIAAAAIAAAAQg3AAg/g+IgCgBQg9g9g4AAIAAAAIAAAAQgfAAgdASIAAAAIgCACQgzAjAABbQAAAfAGAkQgxhBAAhUQAAhrBPhMQBPhMBvAAQBwAABPBMQASASAOASQAvBBAABSQAABrhPBNQhPBMhwAAQhvAAhPhMg");
	this.shape_1.setTransform(0,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Ball, new cjs.Rectangle(-27,-25,54,52), null);


(lib.lives = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(5));

	// Layer_1
	this.ball_mc = new lib.Ball();
	this.ball_mc.name = "ball_mc";
	this.ball_mc.parent = this;
	this.ball_mc.setTransform(111.45,13,0.5,0.5,0,0,0,27,26);

	this.ball_mc_1 = new lib.Ball();
	this.ball_mc_1.name = "ball_mc_1";
	this.ball_mc_1.parent = this;
	this.ball_mc_1.setTransform(78.8,13,0.5,0.5,0,0,0,27,26);

	this.ball_mc_2 = new lib.Ball();
	this.ball_mc_2.name = "ball_mc_2";
	this.ball_mc_2.parent = this;
	this.ball_mc_2.setTransform(46.15,13,0.5,0.5,0,0,0,27,26);

	this.ball_mc_3 = new lib.Ball();
	this.ball_mc_3.name = "ball_mc_3";
	this.ball_mc_3.parent = this;
	this.ball_mc_3.setTransform(13.5,13,0.5,0.5,0,0,0,27,26);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.ball_mc_3},{t:this.ball_mc_2,p:{x:46.15}},{t:this.ball_mc_1,p:{x:78.8}},{t:this.ball_mc,p:{x:111.45}}]}).to({state:[{t:this.ball_mc_2,p:{x:13.5}},{t:this.ball_mc_1,p:{x:46.15}},{t:this.ball_mc,p:{x:78.8}}]},1).to({state:[{t:this.ball_mc_1,p:{x:13.5}},{t:this.ball_mc,p:{x:46.15}}]},1).to({state:[{t:this.ball_mc,p:{x:13.5}}]},1).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-13.5,-12.5,125,26);


// stage content:
(lib.pongv3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Info
	this.info_mc = new lib.Info();
	this.info_mc.name = "info_mc";
	this.info_mc.parent = this;
	this.info_mc.setTransform(325,210,1,1,0,0,0,142,62);
	this.info_mc.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.info_mc).wait(1));

	// Lives
	this.lives_mc = new lib.lives();
	this.lives_mc.name = "lives_mc";
	this.lives_mc.parent = this;
	this.lives_mc.setTransform(50.45,45.5,1,1,0,0,0,27,26);

	this.timeline.addTween(cjs.Tween.get(this.lives_mc).wait(1));

	// Ball
	this.ball_mc = new lib.Ball();
	this.ball_mc.name = "ball_mc";
	this.ball_mc.parent = this;
	this.ball_mc.setTransform(330,100,1,1,0,0,0,0,1);

	this.timeline.addTween(cjs.Tween.get(this.ball_mc).wait(1));

	// Bat
	this.score_txt = new cjs.Text("000", "bold 45px 'Arial Black'", "#CCCCCC");
	this.score_txt.name = "score_txt";
	this.score_txt.textAlign = "center";
	this.score_txt.lineHeight = 66;
	this.score_txt.lineWidth = 133;
	this.score_txt.parent = this;
	this.score_txt.setTransform(603.5,-4);

	this.bat_mc = new lib.Bat();
	this.bat_mc.name = "bat_mc";
	this.bat_mc.parent = this;
	this.bat_mc.setTransform(331.3,329.7,1,1,0,0,0,-0.1,0.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(4,1,1).p("AmFiVIMLAAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAIsLAAQg+AAgsgsQgsgsAAg+QAAg9AsgsQAsgsA+AAg");
	this.shape.setTransform(157,335);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.bat_mc},{t:this.score_txt}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(343.5,181.5,328.5,170.5);
// library properties:
lib.properties = {
	id: 'B0FAC188B4854BAAABD0C6A57D6D97AE',
	width: 667,
	height: 375,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['B0FAC188B4854BAAABD0C6A57D6D97AE'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;