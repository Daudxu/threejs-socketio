(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"rhino_atlas_", frames: [[0,480,456,418],[933,601,46,41],[272,1353,119,85],[0,1353,121,85],[393,1353,145,54],[933,644,44,21],[0,0,489,478],[491,0,489,478],[123,1353,147,69],[896,1112,106,126],[919,1240,90,126],[890,990,134,120],[572,1163,160,132],[458,480,473,222],[578,857,310,151],[578,1010,310,151],[458,704,310,151],[0,900,576,229],[0,1131,570,220],[734,1285,183,99],[770,704,170,127],[890,833,120,155],[572,1297,145,98],[734,1163,160,120],[933,480,86,119]]}
];


// symbols:



(lib.CachedTexturedBitmap_253 = function() {
	this.initialize(ss["rhino_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_254 = function() {
	this.initialize(ss["rhino_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_256 = function() {
	this.initialize(ss["rhino_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_257 = function() {
	this.initialize(ss["rhino_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_259 = function() {
	this.initialize(ss["rhino_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_261 = function() {
	this.initialize(ss["rhino_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_262 = function() {
	this.initialize(ss["rhino_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_263 = function() {
	this.initialize(ss["rhino_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_264 = function() {
	this.initialize(ss["rhino_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_265 = function() {
	this.initialize(ss["rhino_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_266 = function() {
	this.initialize(ss["rhino_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_267 = function() {
	this.initialize(ss["rhino_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_268 = function() {
	this.initialize(ss["rhino_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_269 = function() {
	this.initialize(ss["rhino_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_270 = function() {
	this.initialize(ss["rhino_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_271 = function() {
	this.initialize(ss["rhino_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_272 = function() {
	this.initialize(ss["rhino_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_273 = function() {
	this.initialize(ss["rhino_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_274 = function() {
	this.initialize(ss["rhino_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_275 = function() {
	this.initialize(ss["rhino_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_276 = function() {
	this.initialize(ss["rhino_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_277 = function() {
	this.initialize(ss["rhino_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_278 = function() {
	this.initialize(ss["rhino_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_279 = function() {
	this.initialize(ss["rhino_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_280 = function() {
	this.initialize(ss["rhino_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Scarf = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_280();
	this.instance.parent = this;
	this.instance.setTransform(42.25,-0.5,0.5003,0.5003);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(42.3,-0.5,43,59.6);


(lib.RUpperArm = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_279();
	this.instance.parent = this;
	this.instance.setTransform(92.2,6.7,0.5004,0.5004);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(92.2,6.7,80.10000000000001,60.099999999999994);


(lib.RLowerArm = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_278();
	this.instance.parent = this;
	this.instance.setTransform(45.05,43.8,0.5004,0.5004);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(45.1,43.8,72.5,49.10000000000001);


(lib.RLeg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_277();
	this.instance.parent = this;
	this.instance.setTransform(-0.5,0,0.5004,0.5004);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,0,60.1,77.6);


(lib.RHand = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_276();
	this.instance.parent = this;
	this.instance.setTransform(-0.5,72.1,0.5005,0.5005);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,72.1,85.1,63.599999999999994);


(lib.RFoot = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_275();
	this.instance.parent = this;
	this.instance.setTransform(-0.5,-0.5,0.5004,0.5004);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,91.6,49.6);


(lib.PlayButton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.CachedTexturedBitmap_270();
	this.instance.parent = this;
	this.instance.setTransform(88.55,13.55,0.7246,0.7246);

	this.instance_1 = new lib.CachedTexturedBitmap_271();
	this.instance_1.parent = this;
	this.instance_1.setTransform(88.55,13.55,0.7246,0.7246);

	this.instance_2 = new lib.CachedTexturedBitmap_272();
	this.instance_2.parent = this;
	this.instance_2.setTransform(94.05,24.6,0.7246,0.7246);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[]},1).wait(1));

	// Layer_1
	this.instance_3 = new lib.CachedTexturedBitmap_273();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-7.35,-7.35,0.7246,0.7246);

	this.instance_4 = new lib.CachedTexturedBitmap_274();
	this.instance_4.parent = this;
	this.instance_4.setTransform(0,-3.7,0.7246,0.7246);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3}]}).to({state:[{t:this.instance_4}]},3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.3,-7.3,420.40000000000003,165.9);


(lib.Pelvis = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_269();
	this.instance.parent = this;
	this.instance.setTransform(-0.45,-0.45,0.5003,0.5003);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.4,-0.4,236.6,111);


(lib.LUpperArm = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_268();
	this.instance.parent = this;
	this.instance.setTransform(92.15,0.75,0.5006,0.5006);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(92.2,0.8,80.10000000000001,66.10000000000001);


(lib.LLowerArm = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_267();
	this.instance.parent = this;
	this.instance.setTransform(46.95,36.75,0.5006,0.5006);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(47,36.8,67.1,60.10000000000001);


(lib.LLeg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_266();
	this.instance.parent = this;
	this.instance.setTransform(-0.5,0,0.5004,0.5004);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,0,45.1,63.1);


(lib.LHand = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_265();
	this.instance.parent = this;
	this.instance.setTransform(-0.5,-0.5,0.5005,0.5005);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,53.1,63.1);


(lib.LFoot = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_264();
	this.instance.parent = this;
	this.instance.setTransform(-0.5,-0.5,0.5003,0.5003);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,73.6,34.5);


(lib.Head = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.CachedTexturedBitmap_257();
	this.instance.parent = this;
	this.instance.setTransform(63.25,31,0.5004,0.5004);

	this.instance_1 = new lib.CachedTexturedBitmap_256();
	this.instance_1.parent = this;
	this.instance_1.setTransform(63.7,31,0.5004,0.5004);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},16).to({state:[{t:this.instance_1}]},2).to({state:[{t:this.instance}]},2).to({state:[]},2).wait(28));

	// Eyebrows
	this.instance_2 = new lib.CachedTexturedBitmap_259();
	this.instance_2.parent = this;
	this.instance_2.setTransform(52.3,3.6,0.5004,0.5004);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).wait(25).to({_off:true},1).wait(23));

	// Irises
	this.instance_3 = new lib.CachedTexturedBitmap_261();
	this.instance_3.parent = this;
	this.instance_3.setTransform(86.05,53.2,0.5004,0.5004);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({_off:false},0).wait(25).to({_off:true},1).wait(23));

	// Base
	this.instance_4 = new lib.CachedTexturedBitmap_262();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-0.5,-0.5,0.5004,0.5004);

	this.instance_5 = new lib.CachedTexturedBitmap_263();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-0.5,-0.5,0.5004,0.5004);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},25).to({state:[]},1).wait(23));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,244.7,239.2);


(lib.Controller_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_254();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5002,0.5002);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Controller_Layer_1, null, null);


(lib.Body = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_253();
	this.instance.parent = this;
	this.instance.setTransform(-0.5,-33.95,0.5003,0.5003);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-33.9,228.1,209.1);


(lib.Scene_1_Btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Btn
	this.play_btn = new lib.PlayButton();
	this.play_btn.name = "play_btn";
	this.play_btn.parent = this;
	this.play_btn.setTransform(497.15,700.95,0.69,0.69,0,0,0,201.4,75.6);
	new cjs.ButtonHelper(this.play_btn, 0, 1, 2, false, new lib.PlayButton(), 3);

	this.timeline.addTween(cjs.Tween.get(this.play_btn).to({x:486.65,y:568.95},14,cjs.Ease.bounceOut).to({_off:true},56).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Controller = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.Controller_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(11.5,10.2,1,1,0,0,0,11.5,10.2);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Controller, new cjs.Rectangle(0,0,23,20.5), null);


(lib.Rhino_Armature_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Armature_7
	this.ikNode_46 = new lib.Controller();
	this.ikNode_46.name = "ikNode_46";
	this.ikNode_46.parent = this;
	this.ikNode_46.setTransform(395.55,369.05,0.9993,0.9993,-13.8826,0,0,10,12.7);

	this.instance = new lib.LFoot("single",0);
	this.instance.parent = this;
	this.instance.setTransform(323.75,375.4,0.9994,0.9994,-18.5149,0,0,19.8,9.3);

	this.ikNode_44 = new lib.Controller();
	this.ikNode_44.name = "ikNode_44";
	this.ikNode_44.parent = this;
	this.ikNode_44.setTransform(220.35,396.9,0.999,0.999,34.3646,0,0,9.2,6.7);

	this.instance_1 = new lib.RFoot("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(156.6,386.35,0.9993,0.9993,-5.4836,0,0,38.2,10.3);

	this.ikNode_40 = new lib.Controller();
	this.ikNode_40.name = "ikNode_40";
	this.ikNode_40.parent = this;
	this.ikNode_40.setTransform(232.6,353.65,0.9989,0.9989,-66.0287,0,0,12.3,5.5);

	this.instance_2 = new lib.RLowerArm("single",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(184.7,251.85,0.9991,0.9991,-87.9721,0,0,97.7,59.6);

	this.instance_3 = new lib.RHand("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(208.6,293,0.999,0.999,-83.8659,0,0,55.2,87.2);

	this.ikNode_37 = new lib.Controller();
	this.ikNode_37.name = "ikNode_37";
	this.ikNode_37.parent = this;
	this.ikNode_37.setTransform(275.35,395.75,0.9989,0.9989,58.0653,0,0,11.7,8.6);

	this.instance_4 = new lib.RUpperArm("single",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(166.15,190.4,0.9991,0.9991,-70.9064,0,0,156,18.4);

	this.instance_5 = new lib.Scarf("single",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(193.25,172.2,0.9995,0.9995,1.286,0,0,65.9,26.8);

	this.ikNode_31 = new lib.Controller();
	this.ikNode_31.name = "ikNode_31";
	this.ikNode_31.parent = this;
	this.ikNode_31.setTransform(243.6,4.4,0.9992,0.9992,99.02,0,0,5.7,9.7);

	this.instance_6 = new lib.Head("single",1);
	this.instance_6.parent = this;
	this.instance_6.setTransform(219.95,157.7,0.9993,0.9993,-7.3784,0,0,37.4,150.2);

	this.instance_7 = new lib.Body("single",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(246.35,276.45,0.9995,0.9995,1.286,0,0,121.2,128.6);

	this.instance_8 = new lib.Pelvis("single",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(245.25,327.45,0.9995,0.9995,1.286,0,0,127.1,82.8);

	this.instance_9 = new lib.LLeg("single",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(319.55,341.95,0.9992,0.9992,-6.978,0,0,26.3,17.8);

	this.instance_10 = new lib.RLeg("single",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(158.75,336.05,0.9993,0.9993,-0.4716,0,0,28.6,17.2);

	this.instance_11 = new lib.LUpperArm("single",0);
	this.instance_11.parent = this;
	this.instance_11.setTransform(297.5,217.45,0.9987,0.9987,-35.1972,0,0,154.8,22.1);

	this.instance_12 = new lib.LLowerArm("single",0);
	this.instance_12.parent = this;
	this.instance_12.setTransform(275.1,283.7,0.9987,0.9987,-51.6812,0,0,94.9,63.5);

	this.instance_13 = new lib.LHand("single",0);
	this.instance_13.parent = this;
	this.instance_13.setTransform(264.55,331.7,0.999,0.9989,95.5056,0,0,12.2,38.9);

	this.ikNode_27 = new lib.Controller();
	this.ikNode_27.name = "ikNode_27";
	this.ikNode_27.parent = this;
	this.ikNode_27.setTransform(243.45,368.4,0.9995,0.9995,1.2807,0,0,11.7,11.1);

	this.ikNode_86 = new lib.Controller();
	this.ikNode_86.name = "ikNode_86";
	this.ikNode_86.parent = this;
	this.ikNode_86.setTransform(394.9,391.55,0.9993,0.9993,4.2288,0,0,10,12.7);

	this.ikNode_83 = new lib.Controller();
	this.ikNode_83.name = "ikNode_83";
	this.ikNode_83.parent = this;
	this.ikNode_83.setTransform(220.35,396.8,0.999,0.999,34.3644,0,0,9.2,6.7);

	this.ikNode_76 = new lib.Controller();
	this.ikNode_76.name = "ikNode_76";
	this.ikNode_76.parent = this;
	this.ikNode_76.setTransform(82.9,345.85,0.9988,0.9988,76.5262,0,0,12.4,5.6);

	this.ikNode_80 = new lib.Controller();
	this.ikNode_80.name = "ikNode_80";
	this.ikNode_80.parent = this;
	this.ikNode_80.setTransform(457,304.7,0.9988,0.9988,7.2574,0,0,11.8,8.6);

	this.ikNode_71 = new lib.Controller();
	this.ikNode_71.name = "ikNode_71";
	this.ikNode_71.parent = this;
	this.ikNode_71.setTransform(243.55,4.25,0.9991,0.9991,99.0161,0,0,5.7,9.6);

	this.ikNode_67 = new lib.Controller();
	this.ikNode_67.name = "ikNode_67";
	this.ikNode_67.parent = this;
	this.ikNode_67.setTransform(243.45,368.4,0.9995,0.9995,1.2807,0,0,11.7,11.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.ikNode_27,p:{regX:11.7,rotation:1.2807,x:243.45,y:368.4}},{t:this.instance_13,p:{regY:38.9,scaleX:0.999,rotation:95.5056,x:264.55,y:331.7,scaleY:0.9989,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9987,scaleY:0.9987,rotation:-51.6812,x:275.1,y:283.7,regX:94.9,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9987,scaleY:0.9987,rotation:-35.1972,x:297.5,y:217.45,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9993,scaleY:0.9993,rotation:-0.4716,x:158.75,y:336.05,regY:17.2}},{t:this.instance_9,p:{regX:26.3,scaleX:0.9992,scaleY:0.9992,rotation:-6.978,x:319.55,y:341.95,regY:17.8}},{t:this.instance_8,p:{regX:127.1,regY:82.8,scaleX:0.9995,scaleY:0.9995,rotation:1.286,x:245.25,y:327.45}},{t:this.instance_7,p:{scaleX:0.9995,scaleY:0.9995,rotation:1.286,x:246.35,y:276.45,regY:128.6,regX:121.2}},{t:this.instance_6,p:{regX:37.4,scaleX:0.9993,scaleY:0.9993,rotation:-7.3784,x:219.95,y:157.7,startPosition:1,regY:150.2}},{t:this.ikNode_31,p:{regX:5.7,regY:9.7,scaleX:0.9992,scaleY:0.9992,rotation:99.02,x:243.6,y:4.4}},{t:this.instance_5,p:{scaleX:0.9995,scaleY:0.9995,rotation:1.286,x:193.25,y:172.2,regY:26.8,regX:65.9}},{t:this.instance_4,p:{regX:156,scaleX:0.9991,scaleY:0.9991,rotation:-70.9064,x:166.15,y:190.4,regY:18.4}},{t:this.ikNode_37,p:{regX:11.7,scaleX:0.9989,scaleY:0.9989,rotation:58.0653,x:275.35,y:395.75,regY:8.6}},{t:this.instance_3,p:{rotation:-83.8659,x:208.6,y:293,regX:55.2,scaleX:0.999,scaleY:0.999}},{t:this.instance_2,p:{rotation:-87.9721,x:184.7,y:251.85,scaleX:0.9991,scaleY:0.9991,regX:97.7,regY:59.6}},{t:this.ikNode_40,p:{regY:5.5,scaleX:0.9989,scaleY:0.9989,rotation:-66.0287,x:232.6,y:353.65,regX:12.3}},{t:this.instance_1,p:{regX:38.2,regY:10.3,scaleX:0.9993,scaleY:0.9993,rotation:-5.4836,x:156.6,y:386.35}},{t:this.ikNode_44,p:{scaleX:0.999,scaleY:0.999,rotation:34.3646,x:220.35,y:396.9,regY:6.7,regX:9.2}},{t:this.instance,p:{regY:9.3,rotation:-18.5149,x:323.75,y:375.4,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_46,p:{scaleX:0.9993,scaleY:0.9993,rotation:-13.8826,x:395.55,y:369.05,regX:10,regY:12.7}}]}).to({state:[{t:this.ikNode_27,p:{regX:11.8,rotation:1.2763,x:243.7,y:366.65}},{t:this.instance_13,p:{regY:39,scaleX:0.9989,rotation:92.0686,x:274.55,y:332,scaleY:0.9989,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9986,scaleY:0.9986,rotation:-57.8347,x:279.95,y:283.25,regX:94.9,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-39.4334,x:297.4,y:215.45,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.5,scaleX:0.9992,scaleY:0.9992,rotation:3.4697,x:158.5,y:333.95,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:3.7294,x:319.4,y:340,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2765,x:245.2,y:325.65}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2764,x:246.3,y:274.5,regY:128.6,regX:121.2}},{t:this.instance_6,p:{regX:37.5,scaleX:0.9992,scaleY:0.9992,rotation:-6.6376,x:219.9,y:155.7,startPosition:2,regY:150.2}},{t:this.ikNode_31,p:{regX:5.6,regY:9.6,scaleX:0.9991,scaleY:0.9991,rotation:99.7585,x:245.55,y:2.8}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2764,x:193.2,y:170.2,regY:26.8,regX:65.9}},{t:this.instance_4,p:{regX:155.8,scaleX:0.999,scaleY:0.999,rotation:-67.0387,x:165.9,y:188.7,regY:18.4}},{t:this.ikNode_37,p:{regX:11.8,scaleX:0.9988,scaleY:0.9988,rotation:52.6732,x:289.4,y:395.2,regY:8.6}},{t:this.instance_3,p:{rotation:-87.6451,x:201.4,y:293.7,regX:55.2,scaleX:0.999,scaleY:0.999}},{t:this.instance_2,p:{rotation:-84.1038,x:180.3,y:251.1,scaleX:0.9991,scaleY:0.9991,regX:97.7,regY:59.6}},{t:this.ikNode_40,p:{regY:5.6,scaleX:0.9987,scaleY:0.9987,rotation:-123.391,x:229.35,y:352.5,regX:12.3}},{t:this.instance_1,p:{regX:38.3,regY:10.4,scaleX:0.9992,scaleY:0.9992,rotation:-6.1286,x:153.15,y:384.15}},{t:this.ikNode_44,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.0602,x:216.85,y:394,regY:6.7,regX:9.2}},{t:this.instance,p:{regY:9.2,rotation:-7.661,x:317.35,y:373.5,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_46,p:{scaleX:0.9992,scaleY:0.9992,rotation:-2.5908,x:389.2,y:380.85,regX:10,regY:12.7}}]},1).to({state:[{t:this.ikNode_27,p:{regX:11.8,rotation:1.2658,x:243.6,y:364.65}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9989,rotation:88.6371,x:285,y:331.25,scaleY:0.9989,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9986,scaleY:0.9986,rotation:-63.9874,x:284.9,y:282.4,regX:94.9,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-43.6683,x:297.15,y:213.4,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:7.4161,x:158.6,y:331.9,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:14.4414,x:319.35,y:337.9,regY:17.7}},{t:this.instance_8,p:{regX:127.2,regY:82.8,scaleX:0.9994,scaleY:0.9994,rotation:1.266,x:245.05,y:323.5}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2659,x:246.1,y:272.55,regY:128.6,regX:121.2}},{t:this.instance_6,p:{regX:37.4,scaleX:0.9992,scaleY:0.9992,rotation:-5.8955,x:219.55,y:153.65,startPosition:3,regY:150.2}},{t:this.ikNode_31,p:{regX:5.7,regY:9.7,scaleX:0.9991,scaleY:0.9991,rotation:100.4973,x:247.3,y:1.35}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2659,x:193.1,y:168.3,regY:26.8,regX:65.9}},{t:this.instance_4,p:{regX:156,scaleX:0.999,scaleY:0.999,rotation:-63.1704,x:165.7,y:186.65,regY:18.4}},{t:this.ikNode_37,p:{regX:11.8,scaleX:0.9988,scaleY:0.9988,rotation:47.2815,x:303.55,y:393.45,regY:8.6}},{t:this.instance_3,p:{rotation:-91.4215,x:194.05,y:294.15,regX:55.1,scaleX:0.999,scaleY:0.999}},{t:this.instance_2,p:{rotation:-80.2331,x:175.8,y:250.05,scaleX:0.999,scaleY:0.999,regX:97.7,regY:59.6}},{t:this.ikNode_40,p:{regY:5.6,scaleX:0.9988,scaleY:0.9988,rotation:179.2472,x:225.65,y:350.7,regX:12.3}},{t:this.instance_1,p:{regX:38.3,regY:10.4,scaleX:0.9992,scaleY:0.9992,rotation:-6.7767,x:149.65,y:381.6}},{t:this.ikNode_44,p:{scaleX:0.9989,scaleY:0.9989,rotation:33.7568,x:213.4,y:390.75,regY:6.7,regX:9.2}},{t:this.instance,p:{regY:9.3,rotation:3.1877,x:311.05,y:370.6,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_46,p:{scaleX:0.9992,scaleY:0.9992,rotation:8.6955,x:380.5,y:391.2,regX:10.1,regY:12.7}}]},1).to({state:[{t:this.ikNode_27,p:{regX:11.8,rotation:1.2571,x:243.6,y:362.7}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9989,rotation:85.1971,x:295.3,y:329.65,scaleY:0.9989,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9986,scaleY:0.9986,rotation:-70.1414,x:289.95,y:281.15,regX:94.9,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-47.9052,x:297.15,y:211.55,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:18.3791,x:158.55,y:329.8,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:11.6904,x:319.25,y:335.95,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2572,x:245.1,y:321.65}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2572,x:246.05,y:270.5,regY:128.6,regX:121.2}},{t:this.instance_6,p:{regX:37.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.1554,x:219.6,y:151.65,startPosition:4,regY:150.2}},{t:this.ikNode_31,p:{regX:5.7,regY:9.6,scaleX:0.9991,scaleY:0.9991,rotation:101.2385,x:249.35,y:-0.2}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2572,x:193.05,y:166.4,regY:26.9,regX:65.9}},{t:this.instance_4,p:{regX:155.9,scaleX:0.999,scaleY:0.999,rotation:-59.2464,x:165.65,y:184.9,regY:18.5}},{t:this.ikNode_37,p:{regX:11.7,scaleX:0.9988,scaleY:0.9988,rotation:41.8895,x:317.55,y:390.5,regY:8.6}},{t:this.instance_3,p:{rotation:-82.7012,x:186.55,y:293.75,regX:55.2,scaleX:0.9989,scaleY:0.9989}},{t:this.instance_2,p:{rotation:-76.4496,x:171.25,y:248.6,scaleX:0.9991,scaleY:0.9991,regX:97.7,regY:59.6}},{t:this.ikNode_40,p:{regY:5.6,scaleX:0.9988,scaleY:0.9988,rotation:-145.6,x:209.2,y:354.6,regX:12.3}},{t:this.instance_1,p:{regX:38.3,regY:10.4,scaleX:0.9992,scaleY:0.9992,rotation:6.2493,x:140.15,y:376.95}},{t:this.ikNode_44,p:{scaleX:0.9989,scaleY:0.9989,rotation:55.3576,x:200.15,y:400.25,regY:6.7,regX:9.2}},{t:this.instance,p:{regY:9.3,rotation:3.4542,x:312.65,y:369.05,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_46,p:{scaleX:0.9992,scaleY:0.9992,rotation:4.9374,x:381.8,y:389.8,regX:10,regY:12.7}}]},1).to({state:[{t:this.ikNode_27,p:{regX:11.8,rotation:1.2483,x:243.5,y:360.75}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9989,rotation:81.76,x:305.6,y:327.05,scaleY:0.9989,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9986,scaleY:0.9986,rotation:-76.2937,x:295.05,y:279.55,regX:94.9,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-52.1411,x:296.9,y:209.55,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9991,scaleY:0.9991,rotation:29.3433,x:158.55,y:327.75,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:8.9417,x:319.15,y:333.95,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.8,scaleX:0.9994,scaleY:0.9994,rotation:1.2484,x:245,y:319.55}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2484,x:245.95,y:268.55,regY:128.6,regX:121.2}},{t:this.instance_6,p:{regX:37.5,scaleX:0.9992,scaleY:0.9992,rotation:-4.4142,x:219.45,y:149.7,startPosition:5,regY:150.2}},{t:this.ikNode_31,p:{regX:5.6,regY:9.6,scaleX:0.9991,scaleY:0.9991,rotation:101.9799,x:251.25,y:-1.9}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2484,x:193,y:164.45,regY:26.9,regX:65.9}},{t:this.instance_4,p:{regX:155.9,scaleX:0.999,scaleY:0.999,rotation:-55.3218,x:165.4,y:182.9,regY:18.4}},{t:this.ikNode_37,p:{regX:11.7,scaleX:0.9988,scaleY:0.9988,rotation:36.4984,x:331.5,y:386.4,regY:8.6}},{t:this.instance_3,p:{rotation:-73.9753,x:178.9,y:292.95,regX:55.2,scaleX:0.9989,scaleY:0.9989}},{t:this.instance_2,p:{rotation:-72.6646,x:166.65,y:246.9,scaleX:0.999,scaleY:0.999,regX:97.7,regY:59.6}},{t:this.ikNode_40,p:{regY:5.6,scaleX:0.9988,scaleY:0.9988,rotation:-110.443,x:192.05,y:356.65,regX:12.3}},{t:this.instance_1,p:{regX:38.2,regY:10.4,scaleX:0.9992,scaleY:0.9992,rotation:19.2781,x:131.25,y:370.45}},{t:this.ikNode_44,p:{scaleX:0.9989,scaleY:0.9989,rotation:76.9572,x:184.5,y:406.8,regY:6.7,regX:9.2}},{t:this.instance,p:{regY:9.3,rotation:3.7206,x:314.2,y:367.25,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_46,p:{scaleX:0.9992,scaleY:0.9992,rotation:1.1813,x:383.35,y:388.4,regX:10,regY:12.7}}]},1).to({state:[{t:this.ikNode_27,p:{regX:11.8,rotation:1.2396,x:243.45,y:358.8}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9989,rotation:78.3214,x:315.8,y:323.6,scaleY:0.9989,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9986,scaleY:0.9986,rotation:-82.4474,x:300.15,y:277.6,regX:94.9,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-56.3779,x:296.9,y:207.5,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.5,scaleX:0.9992,scaleY:0.9992,rotation:40.3055,x:158.45,y:325.55,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:6.1917,x:319.05,y:331.95,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.8,scaleX:0.9994,scaleY:0.9994,rotation:1.2397,x:244.85,y:317.5}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2397,x:245.9,y:266.45,regY:128.6,regX:121.2}},{t:this.instance_6,p:{regX:37.5,scaleX:0.9992,scaleY:0.9992,rotation:-3.673,x:219.3,y:147.7,startPosition:6,regY:150.2}},{t:this.ikNode_31,p:{regX:5.7,regY:9.6,scaleX:0.9991,scaleY:0.9991,rotation:102.719,x:253.15,y:-3.35}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2397,x:193,y:162.3,regY:26.8,regX:65.9}},{t:this.instance_4,p:{regX:155.8,scaleX:0.999,scaleY:0.999,rotation:-51.3981,x:165.25,y:181,regY:18.4}},{t:this.ikNode_37,p:{regX:11.7,scaleX:0.9988,scaleY:0.9988,rotation:31.1061,x:345.15,y:381.2,regY:8.6}},{t:this.instance_3,p:{rotation:-65.2498,x:171.35,y:291.7,regX:55.2,scaleX:0.9989,scaleY:0.9989}},{t:this.instance_2,p:{rotation:-68.8806,x:162.1,y:244.85,scaleX:0.9991,scaleY:0.9991,regX:97.7,regY:59.6}},{t:this.ikNode_40,p:{regY:5.5,scaleX:0.9988,scaleY:0.9988,rotation:-75.2918,x:174.4,y:356.65,regX:12.3}},{t:this.instance_1,p:{regX:38.3,regY:10.4,scaleX:0.9992,scaleY:0.9992,rotation:32.3081,x:123.6,y:362.45}},{t:this.ikNode_44,p:{scaleX:0.9989,scaleY:0.9989,rotation:98.5537,x:167.35,y:409.7,regY:6.6,regX:9.2}},{t:this.instance,p:{regY:9.2,rotation:3.9871,x:315.8,y:365.35,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_46,p:{scaleX:0.9992,scaleY:0.9992,rotation:-2.5733,x:384.85,y:386.95,regX:10,regY:12.7}}]},1).to({state:[{t:this.ikNode_27,p:{regX:11.8,rotation:1.2309,x:243.35,y:356.8}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9989,rotation:74.883,x:325.75,y:319.25,scaleY:0.9989,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9987,scaleY:0.9987,rotation:-88.5991,x:305.3,y:275.2,regX:94.9,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-60.6133,x:296.85,y:205.7,regY:22.2,regX:154.8}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:51.269,x:158.55,y:323.6,regY:17.1}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:3.441,x:319,y:329.95,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2309,x:244.8,y:315.7}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.23,x:245.85,y:264.5,regY:128.6,regX:121.2}},{t:this.instance_6,p:{regX:37.5,scaleX:0.9992,scaleY:0.9992,rotation:-2.9333,x:219.2,y:146,startPosition:7,regY:150.3}},{t:this.ikNode_31,p:{regX:5.7,regY:9.6,scaleX:0.9991,scaleY:0.9991,rotation:103.4604,x:255,y:-4.8}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.23,x:193.05,y:160.35,regY:26.8,regX:66}},{t:this.instance_4,p:{regX:155.9,scaleX:0.999,scaleY:0.999,rotation:-47.4735,x:165.2,y:178.95,regY:18.4}},{t:this.ikNode_37,p:{regX:11.7,scaleX:0.9988,scaleY:0.9988,rotation:25.714,x:358.55,y:374.8,regY:8.6}},{t:this.instance_3,p:{rotation:-56.5243,x:163.65,y:289.9,regX:55.2,scaleX:0.9989,scaleY:0.9989}},{t:this.instance_2,p:{rotation:-65.0965,x:157.5,y:242.5,scaleX:0.9991,scaleY:0.9991,regX:97.7,regY:59.6}},{t:this.ikNode_40,p:{regY:5.7,scaleX:0.9988,scaleY:0.9988,rotation:-40.1346,x:156.8,y:354.8,regX:12.2}},{t:this.instance_1,p:{regX:38.3,regY:10.4,scaleX:0.9992,scaleY:0.9992,rotation:45.3378,x:117.1,y:352.95}},{t:this.ikNode_44,p:{scaleX:0.9989,scaleY:0.9989,rotation:120.1535,x:148.9,y:408.9,regY:6.7,regX:9.2}},{t:this.instance,p:{regY:9.2,rotation:4.2538,x:317.4,y:363.45,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_46,p:{scaleX:0.9992,scaleY:0.9992,rotation:-6.33,x:386.45,y:385.35,regX:10,regY:12.7}}]},1).to({state:[{t:this.ikNode_27,p:{regX:11.8,rotation:1.2274,x:243.5,y:358.8}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9989,rotation:71.4394,x:335.5,y:318.05,scaleY:0.9989,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9986,scaleY:0.9986,rotation:-94.7426,x:310.45,y:276.3,regX:94.9,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-64.85,x:296.9,y:207.6,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:36.8093,x:158.65,y:325.6,regY:17.1}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:10.7637,x:319,y:331.8,regY:17.7}},{t:this.instance_8,p:{regX:127.2,regY:82.8,scaleX:0.9994,scaleY:0.9994,rotation:1.2274,x:244.9,y:317.5}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2265,x:245.9,y:266.55,regY:128.6,regX:121.2}},{t:this.instance_6,p:{regX:37.5,scaleX:0.9992,scaleY:0.9992,rotation:-3.6792,x:219.3,y:147.75,startPosition:8,regY:150.2}},{t:this.ikNode_31,p:{regX:5.7,regY:9.6,scaleX:0.9991,scaleY:0.9991,rotation:102.7283,x:253.05,y:-3.3}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2265,x:193.05,y:162.35,regY:26.8,regX:66}},{t:this.instance_4,p:{regX:155.9,scaleX:0.999,scaleY:0.999,rotation:-43.5667,x:165.3,y:180.9,regY:18.4}},{t:this.ikNode_37,p:{regX:11.7,scaleX:0.9988,scaleY:0.9988,rotation:20.3245,x:371.55,y:371.6,regY:8.6}},{t:this.instance_3,p:{rotation:-51.9651,x:156.3,y:291.4,regX:55.2,scaleX:0.9989,scaleY:0.9989}},{t:this.instance_2,p:{rotation:-61.2781,x:153.35,y:243.8,scaleX:0.999,scaleY:0.999,regX:97.7,regY:59.6}},{t:this.ikNode_40,p:{regY:5.6,scaleX:0.9987,scaleY:0.9987,rotation:-35.8183,x:144.35,y:355.55,regX:12.2}},{t:this.instance_1,p:{regX:38.3,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:34.1378,x:125.75,y:364.55}},{t:this.ikNode_44,p:{scaleX:0.9989,scaleY:0.9989,rotation:93.9161,x:167.95,y:413.15,regY:6.7,regX:9.2}},{t:this.instance,p:{regY:9.3,rotation:4.0161,x:313.1,y:365.1,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_46,p:{scaleX:0.9992,scaleY:0.9992,rotation:23.0846,x:382.2,y:386.55,regX:10,regY:12.7}}]},1).to({state:[{t:this.ikNode_27,p:{regX:11.8,rotation:1.2247,x:243.5,y:360.75}},{t:this.instance_13,p:{regY:39,scaleX:0.9989,rotation:67.9959,x:344.8,y:316,scaleY:0.9989,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9987,scaleY:0.9987,rotation:-100.8896,x:315.4,y:277.25,regX:94.8,regY:63.4}},{t:this.instance_11,p:{scaleX:0.9987,scaleY:0.9987,rotation:-69.0838,x:296.95,y:209.5,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:22.3503,x:158.6,y:327.75,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:18.0863,x:319.1,y:333.8,regY:17.7}},{t:this.instance_8,p:{regX:127.2,regY:82.8,scaleX:0.9994,scaleY:0.9994,rotation:1.2248,x:245,y:319.5}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2248,x:246,y:268.55,regY:128.6,regX:121.2}},{t:this.instance_6,p:{regX:37.5,scaleX:0.9992,scaleY:0.9992,rotation:-4.4257,x:219.35,y:149.8,startPosition:9,regY:150.2}},{t:this.ikNode_31,p:{regX:5.6,regY:9.6,scaleX:0.9991,scaleY:0.9991,rotation:101.9971,x:251.1,y:-2}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2248,x:193.05,y:164.35,regY:26.8,regX:66}},{t:this.instance_4,p:{regX:155.9,scaleX:0.999,scaleY:0.999,rotation:-39.66,x:165.5,y:182.85,regY:18.4}},{t:this.ikNode_37,p:{regX:11.7,scaleX:0.9988,scaleY:0.9988,rotation:14.9371,x:384.15,y:367.35,regY:8.6}},{t:this.instance_3,p:{rotation:-47.4044,x:149,y:292.5,regX:55.2,scaleX:0.9989,scaleY:0.9989}},{t:this.instance_2,p:{rotation:-57.4583,x:149.3,y:244.8,scaleX:0.999,scaleY:0.999,regX:97.7,regY:59.6}},{t:this.ikNode_40,p:{regY:5.6,scaleX:0.9987,scaleY:0.9987,rotation:-31.5018,x:132.05,y:355.5,regX:12.2}},{t:this.instance_1,p:{regX:38.3,regY:10.3,scaleX:0.9992,scaleY:0.9992,rotation:22.9387,x:136.75,y:373.4}},{t:this.ikNode_44,p:{scaleX:0.9989,scaleY:0.9989,rotation:67.6821,x:187.5,y:413,regY:6.7,regX:9.1}},{t:this.instance,p:{regY:9.2,rotation:3.7784,x:308.95,y:365.9,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_46,p:{scaleX:0.9992,scaleY:0.9992,rotation:52.5034,x:378.1,y:387.3,regX:10,regY:12.7}}]},1).to({state:[{t:this.ikNode_27,p:{regX:11.8,rotation:1.2212,x:243.65,y:362.7}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9989,rotation:64.5522,x:353.95,y:313.05,scaleY:0.9989,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9986,scaleY:0.9986,rotation:-107.0381,x:320.6,y:277.55,regX:94.8,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-73.32,x:297.05,y:211.45,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:7.8921,x:158.55,y:329.7,regY:17.1}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:25.407,x:319.1,y:335.9,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.8,scaleX:0.9994,scaleY:0.9994,rotation:1.2222,x:245.05,y:321.45}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2213,x:246.05,y:270.55,regY:128.6,regX:121.2}},{t:this.instance_6,p:{regX:37.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.1729,x:219.45,y:151.65,startPosition:10,regY:150.2}},{t:this.ikNode_31,p:{regX:5.7,regY:9.6,scaleX:0.9991,scaleY:0.9991,rotation:101.2653,x:249.15,y:-0.2}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2213,x:193,y:166.3,regY:26.8,regX:65.9}},{t:this.instance_4,p:{regX:155.9,scaleX:0.999,scaleY:0.999,rotation:-35.7531,x:165.6,y:184.75,regY:18.4}},{t:this.ikNode_37,p:{regX:11.7,scaleX:0.9988,scaleY:0.9988,rotation:9.5484,x:396.1,y:362.15,regY:8.6}},{t:this.instance_3,p:{rotation:-42.8452,x:141.85,y:293.05,regX:55.2,scaleX:0.9989,scaleY:0.9989}},{t:this.instance_2,p:{rotation:-53.6406,x:145.2,y:245.45,scaleX:0.999,scaleY:0.999,regX:97.7,regY:59.6}},{t:this.ikNode_40,p:{regY:5.7,scaleX:0.9987,scaleY:0.9987,rotation:-27.1844,x:120.1,y:354.55,regX:12.3}},{t:this.instance_1,p:{regX:38.3,regY:10.4,scaleX:0.9992,scaleY:0.9992,rotation:11.7384,x:148.85,y:379.5}},{t:this.ikNode_44,p:{scaleX:0.9989,scaleY:0.9989,rotation:41.4448,x:206.5,y:408.55,regY:6.7,regX:9.2}},{t:this.instance,p:{regY:9.3,rotation:3.5392,x:305,y:366.5,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_46,p:{scaleX:0.9992,scaleY:0.9992,rotation:81.9219,x:374.1,y:387.6,regX:10.1,regY:12.7}}]},1).to({state:[{t:this.ikNode_27,p:{regX:11.8,rotation:1.2186,x:243.7,y:364.65}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9989,rotation:61.1077,x:362.4,y:309.35,scaleY:0.9989,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9986,scaleY:0.9986,rotation:-113.1854,x:325.35,y:277.55,regX:94.9,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-77.5541,x:297.1,y:213.4,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-6.5627,x:158.6,y:331.9,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:32.7301,x:319.3,y:337.85,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.8,scaleX:0.9994,scaleY:0.9994,rotation:1.2187,x:245.1,y:323.45}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2178,x:246.15,y:272.45,regY:128.6,regX:121.2}},{t:this.instance_6,p:{regX:37.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.9184,x:219.5,y:153.85,startPosition:11,regY:150.3}},{t:this.ikNode_31,p:{regX:5.7,regY:9.7,scaleX:0.9991,scaleY:0.9991,rotation:100.5328,x:247,y:1.3}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2178,x:193,y:168.25,regY:26.8,regX:65.9}},{t:this.instance_4,p:{regX:156,scaleX:0.999,scaleY:0.999,rotation:-31.8454,x:165.8,y:186.6,regY:18.4}},{t:this.ikNode_37,p:{regX:11.7,scaleX:0.9988,scaleY:0.9988,rotation:4.1596,x:407.45,y:355.9,regY:8.6}},{t:this.instance_3,p:{rotation:-38.2854,x:134.7,y:293.15,regX:55.2,scaleX:0.9989,scaleY:0.9989}},{t:this.instance_2,p:{rotation:-49.8223,x:141.25,y:245.95,scaleX:0.999,scaleY:0.999,regX:97.7,regY:59.6}},{t:this.ikNode_40,p:{regY:5.6,scaleX:0.9988,scaleY:0.9988,rotation:-22.8691,x:108.05,y:352.65,regX:12.2}},{t:this.instance_1,p:{regX:38.3,regY:10.4,scaleX:0.9992,scaleY:0.9992,rotation:0.5407,x:161.65,y:382.4}},{t:this.ikNode_44,p:{scaleX:0.9989,scaleY:0.9989,rotation:15.2081,x:223.85,y:399.5,regY:6.7,regX:9.1}},{t:this.instance,p:{regY:9.3,rotation:3.3016,x:301.15,y:366.35,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_46,p:{scaleX:0.9992,scaleY:0.9992,rotation:111.3367,x:370.35,y:387.05,regX:10,regY:12.7}}]},1).to({state:[{t:this.ikNode_27,p:{regX:11.8,rotation:1.2151,x:243.75,y:366.6}},{t:this.instance_13,p:{regY:39,scaleX:0.9989,rotation:57.6649,x:370.25,y:305.1,scaleY:0.9989,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9986,scaleY:0.9986,rotation:-119.3322,x:330.1,y:277.2,regX:94.9,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9987,scaleY:0.9987,rotation:-81.79,x:297.15,y:215.35,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-21.0213,x:158.55,y:333.95,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:40.0524,x:319.35,y:339.9,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.8,scaleX:0.9994,scaleY:0.9994,rotation:1.2152,x:245.15,y:325.35}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2152,x:246.2,y:274.4,regY:128.6,regX:121.2}},{t:this.instance_6,p:{regX:37.5,scaleX:0.9992,scaleY:0.9992,rotation:-6.6667,x:219.6,y:155.65,startPosition:12,regY:150.2}},{t:this.ikNode_31,p:{regX:5.6,regY:9.6,scaleX:0.9991,scaleY:0.9991,rotation:99.8011,x:245.25,y:2.75}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2152,x:193,y:170.2,regY:26.8,regX:65.9}},{t:this.instance_4,p:{regX:155.9,scaleX:0.999,scaleY:0.999,rotation:-27.9389,x:165.85,y:188.75,regY:18.5}},{t:this.ikNode_37,p:{regX:11.8,scaleX:0.9988,scaleY:0.9988,rotation:-1.2247,x:418.25,y:348.85,regY:8.6}},{t:this.instance_3,p:{rotation:-33.7248,x:127.6,y:292.75,regX:55.1,scaleX:0.9989,scaleY:0.9989}},{t:this.instance_2,p:{rotation:-46.0025,x:137.45,y:246.1,scaleX:0.999,scaleY:0.999,regX:97.7,regY:59.6}},{t:this.ikNode_40,p:{regY:5.6,scaleX:0.9988,scaleY:0.9988,rotation:-18.5515,x:96.6,y:349.95,regX:12.3}},{t:this.instance_1,p:{regX:38.2,regY:10.4,scaleX:0.9992,scaleY:0.9992,rotation:-10.653,x:174.15,y:382}},{t:this.ikNode_44,p:{scaleX:0.9989,scaleY:0.9989,rotation:-11.0265,x:238.6,y:386.6,regY:6.6,regX:9.1}},{t:this.instance,p:{regY:9.3,rotation:3.0633,x:297.7,y:365.75,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_46,p:{scaleX:0.9992,scaleY:0.9992,rotation:140.7561,x:366.8,y:386.1,regX:10,regY:12.8}}]},1).to({state:[{t:this.ikNode_27,p:{regX:11.8,rotation:1.2107,x:243.85,y:368.55}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9989,rotation:54.2211,x:377.65,y:300,scaleY:0.9989,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9986,scaleY:0.9986,rotation:-125.4809,x:334.6,y:276.6,regX:94.9,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9987,scaleY:0.9987,rotation:-86.025,x:297.3,y:217.35,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-35.4811,x:158.55,y:336.05,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:47.3743,x:319.5,y:341.85,regY:17.7}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2117,x:245.3,y:327.4}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2117,x:246.35,y:276.35,regY:128.6,regX:121.2}},{t:this.instance_6,p:{regX:37.5,scaleX:0.9992,scaleY:0.9992,rotation:-7.4115,x:219.75,y:157.6,startPosition:13,regY:150.2}},{t:this.ikNode_31,p:{regX:5.7,regY:9.6,scaleX:0.9991,scaleY:0.9991,rotation:99.0703,x:243.25,y:4.4}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2117,x:193,y:172.25,regY:26.9,regX:65.9}},{t:this.instance_4,p:{regX:155.9,scaleX:0.999,scaleY:0.999,rotation:-24.0325,x:166,y:190.5,regY:18.4}},{t:this.ikNode_37,p:{regX:11.7,scaleX:0.9988,scaleY:0.9988,rotation:-6.613,x:428,y:341,regY:8.6}},{t:this.instance_3,p:{rotation:-29.1649,x:120.85,y:291.85,regX:55.2,scaleX:0.9989,scaleY:0.9989}},{t:this.instance_2,p:{rotation:-42.1859,x:133.75,y:245.95,scaleX:0.999,scaleY:0.999,regX:97.7,regY:59.6}},{t:this.ikNode_40,p:{regY:5.6,scaleX:0.9988,scaleY:0.9988,rotation:-14.2354,x:85.35,y:346.4,regX:12.3}},{t:this.instance_1,p:{regX:38.2,regY:10.4,scaleX:0.9992,scaleY:0.9992,rotation:-21.8528,x:185.65,y:378.55}},{t:this.ikNode_44,p:{scaleX:0.9989,scaleY:0.9989,rotation:-37.2641,x:249.8,y:370.55,regY:6.6,regX:9.1}},{t:this.instance,p:{regY:9.3,rotation:2.8268,x:294.6,y:364.75,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_46,p:{scaleX:0.9992,scaleY:0.9992,rotation:170.1742,x:363.85,y:384.9,regX:10,regY:12.7}}]},1).to({state:[{t:this.ikNode_27,p:{regX:11.8,rotation:1.1994,x:243.75,y:366.6}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9989,rotation:44.9041,x:370.05,y:305.25,scaleY:0.9989,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9986,scaleY:0.9986,rotation:-119.1081,x:329.7,y:277.25,regX:94.9,regY:63.4}},{t:this.instance_11,p:{scaleX:0.9987,scaleY:0.9987,rotation:-81.6343,x:297.2,y:215.35,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9991,scaleY:0.9991,rotation:-37.5325,x:158.55,y:334,regY:17.2}},{t:this.instance_9,p:{regX:26.3,scaleX:0.9991,scaleY:0.9991,rotation:45.4301,x:319.25,y:339.8,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.8,scaleX:0.9994,scaleY:0.9994,rotation:1.2003,x:245.2,y:325.4}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2003,x:246.2,y:274.5,regY:128.6,regX:121.2}},{t:this.instance_6,p:{regX:37.5,scaleX:0.9992,scaleY:0.9992,rotation:-6.443,x:219.55,y:155.7,startPosition:14,regY:150.2}},{t:this.ikNode_31,p:{regX:5.7,regY:9.6,scaleX:0.9991,scaleY:0.9991,rotation:100.0534,x:245.65,y:3.05}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2003,x:193,y:170.4,regY:26.9,regX:65.9}},{t:this.instance_4,p:{regX:155.9,scaleX:0.999,scaleY:0.999,rotation:-27.9514,x:165.85,y:188.7,regY:18.5}},{t:this.ikNode_37,p:{regX:11.7,scaleX:0.9988,scaleY:0.9988,rotation:54.9607,x:426.15,y:337.5,regY:8.6}},{t:this.instance_3,p:{rotation:-33.758,x:127.7,y:292.7,regX:55.2,scaleX:0.9989,scaleY:0.9989}},{t:this.instance_2,p:{rotation:-46.0396,x:137.35,y:246.2,scaleX:0.999,scaleY:0.999,regX:97.6,regY:59.6}},{t:this.ikNode_40,p:{regY:5.6,scaleX:0.9988,scaleY:0.9988,rotation:-18.5468,x:96.65,y:350,regX:12.3}},{t:this.instance_1,p:{regX:38.3,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-15.9527,x:187.3,y:375.6}},{t:this.ikNode_44,p:{scaleX:0.9989,scaleY:0.9989,rotation:-99.9866,x:251.7,y:374.1,regY:6.7,regX:9.2}},{t:this.instance,p:{regY:9.3,rotation:2.9284,x:295.4,y:363.6,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_46,p:{scaleX:0.9992,scaleY:0.9992,rotation:142.7318,x:364.65,y:383.8,regX:10,regY:12.7}}]},1).to({state:[{t:this.ikNode_27,p:{regX:11.8,rotation:1.188,x:243.75,y:364.65}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9989,rotation:35.5888,x:361.7,y:309.8,scaleY:0.9989,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9986,scaleY:0.9986,rotation:-112.7346,x:324.95,y:277.55,regX:94.9,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9987,scaleY:0.9987,rotation:-77.2412,x:297.1,y:213.35,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9991,scaleY:0.9991,rotation:-39.5836,x:158.6,y:331.85,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:43.4851,x:319.25,y:337.9,regY:17.7}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.189,x:245.2,y:323.55}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.188,x:246.1,y:272.4,regY:128.6,regX:121.2}},{t:this.instance_6,p:{regX:37.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.4734,x:219.3,y:153.65,startPosition:15,regY:150.2}},{t:this.ikNode_31,p:{regX:5.7,regY:9.6,scaleX:0.9991,scaleY:0.9991,rotation:101.0352,x:248.15,y:1.6}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.188,x:192.9,y:168.2,regY:26.8,regX:65.9}},{t:this.instance_4,p:{regX:155.9,scaleX:0.999,scaleY:0.999,rotation:-31.8725,x:165.55,y:186.7,regY:18.4}},{t:this.ikNode_37,p:{regX:11.7,scaleX:0.9988,scaleY:0.9988,rotation:116.5322,x:422.3,y:332.35,regY:8.6}},{t:this.instance_3,p:{rotation:-38.3509,x:134.6,y:293.15,regX:55.2,scaleX:0.9989,scaleY:0.9989}},{t:this.instance_2,p:{rotation:-49.8962,x:141.15,y:246.05,scaleX:0.9991,scaleY:0.9991,regX:97.7,regY:59.6}},{t:this.ikNode_40,p:{regY:5.6,scaleX:0.9988,scaleY:0.9988,rotation:-22.8572,x:108.05,y:352.7,regX:12.2}},{t:this.instance_1,p:{regX:38.3,regY:10.4,scaleX:0.9992,scaleY:0.9992,rotation:-10.0517,x:188.6,y:372.55}},{t:this.ikNode_44,p:{scaleX:0.9989,scaleY:0.9989,rotation:-162.7126,x:252.8,y:377.7,regY:6.7,regX:9.2}},{t:this.instance,p:{regY:9.3,rotation:3.03,x:296.1,y:362.45,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_46,p:{scaleX:0.9992,scaleY:0.9992,rotation:115.2889,x:365.5,y:382.7,regX:10,regY:12.7}}]},1).to({state:[{t:this.ikNode_27,p:{regX:11.8,rotation:1.1775,x:243.6,y:362.7}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9989,rotation:45.3132,x:353.35,y:313.2,scaleY:0.9989,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9986,scaleY:0.9986,rotation:-106.7526,x:320.15,y:277.45,regX:94.9,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9987,scaleY:0.9987,rotation:-73.1144,x:296.95,y:211.4,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9991,scaleY:0.9991,rotation:-33.8163,x:158.6,y:329.8,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:45.8013,x:319.1,y:335.8,regY:17.7}},{t:this.instance_8,p:{regX:127.2,regY:82.8,scaleX:0.9994,scaleY:0.9994,rotation:1.1784,x:245.05,y:321.45}},{t:this.instance_7,p:{scaleX:0.9995,scaleY:0.9995,rotation:1.1775,x:246,y:270.5,regY:128.6,regX:121.2}},{t:this.instance_6,p:{regX:37.5,scaleX:0.9992,scaleY:0.9992,rotation:-4.5047,x:219.3,y:151.65,startPosition:16,regY:150.2}},{t:this.ikNode_31,p:{regX:5.7,regY:9.7,scaleX:0.9991,scaleY:0.9991,rotation:102.0194,x:250.55,y:0.1}},{t:this.instance_5,p:{scaleX:0.9995,scaleY:0.9995,rotation:1.1775,x:192.8,y:166.35,regY:26.8,regX:65.9}},{t:this.instance_4,p:{regX:156,scaleX:0.999,scaleY:0.999,rotation:-35.7927,x:165.45,y:184.75,regY:18.4}},{t:this.ikNode_37,p:{regX:11.7,scaleX:0.9988,scaleY:0.9988,rotation:93.7008,x:409.35,y:345.65,regY:8.5}},{t:this.instance_3,p:{rotation:-42.9443,x:141.75,y:293.15,regX:55.2,scaleX:0.9989,scaleY:0.9989}},{t:this.instance_2,p:{rotation:-53.7527,x:145.05,y:245.6,scaleX:0.999,scaleY:0.999,regX:97.7,regY:59.6}},{t:this.ikNode_40,p:{regY:5.7,scaleX:0.9988,scaleY:0.9988,rotation:-27.1703,x:120.15,y:354.65,regX:12.3}},{t:this.instance_1,p:{regX:38.2,regY:10.4,scaleX:0.9992,scaleY:0.9992,rotation:-9.2599,x:184.15,y:373.4}},{t:this.ikNode_44,p:{scaleX:0.9989,scaleY:0.9989,rotation:-164.4979,x:248.55,y:379.55,regY:6.7,regX:9.1}},{t:this.instance,p:{regY:9.3,rotation:13.6473,x:295.1,y:359.5,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_46,p:{scaleX:0.9992,scaleY:0.9992,rotation:156.3972,x:359.6,y:392.1,regX:10,regY:12.8}}]},1).to({state:[{t:this.ikNode_27,p:{regX:11.8,rotation:1.167,x:243.5,y:360.75}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9989,rotation:55.0378,x:344.5,y:315.95,scaleY:0.9989,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9986,scaleY:0.9986,rotation:-100.7712,x:315.25,y:277,regX:94.9,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9987,scaleY:0.9987,rotation:-68.9879,x:296.85,y:209.4,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9991,scaleY:0.9991,rotation:-28.0487,x:158.6,y:327.65,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:48.1208,x:318.95,y:333.9,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.1671,x:244.9,y:319.55}},{t:this.instance_7,p:{scaleX:0.9995,scaleY:0.9995,rotation:1.167,x:245.85,y:268.45,regY:128.6,regX:121.2}},{t:this.instance_6,p:{regX:37.5,scaleX:0.9992,scaleY:0.9992,rotation:-3.5363,x:219.15,y:149.75,startPosition:17,regY:150.2}},{t:this.ikNode_31,p:{regX:5.7,regY:9.6,scaleX:0.9991,scaleY:0.9991,rotation:103.0018,x:253.25,y:-1.25}},{t:this.instance_5,p:{scaleX:0.9995,scaleY:0.9995,rotation:1.167,x:192.75,y:164.45,regY:26.9,regX:65.9}},{t:this.instance_4,p:{regX:155.9,scaleX:0.999,scaleY:0.999,rotation:-39.714,x:165.3,y:183,regY:18.5}},{t:this.ikNode_37,p:{regX:11.7,scaleX:0.9988,scaleY:0.9988,rotation:70.8736,x:394.3,y:357.3,regY:8.5}},{t:this.instance_3,p:{rotation:-47.5376,x:148.95,y:292.55,regX:55.2,scaleX:0.9989,scaleY:0.9989}},{t:this.instance_2,p:{rotation:-57.6066,x:149.1,y:244.95,scaleX:0.9991,scaleY:0.9991,regX:97.7,regY:59.6}},{t:this.ikNode_40,p:{regY:5.6,scaleX:0.9988,scaleY:0.9988,rotation:-31.4824,x:132.3,y:355.55,regX:12.3}},{t:this.instance_1,p:{regX:38.3,regY:10.4,scaleX:0.9992,scaleY:0.9992,rotation:-8.4682,x:179.85,y:373.75}},{t:this.ikNode_44,p:{scaleX:0.9989,scaleY:0.9989,rotation:-166.2834,x:243.75,y:380.8,regY:6.7,regX:9.2}},{t:this.instance,p:{regY:9.2,rotation:24.2651,x:294.2,y:356.55,scaleX:0.9993,scaleY:0.9993,regX:19.8}},{t:this.ikNode_46,p:{scaleX:0.9992,scaleY:0.9992,rotation:-162.4992,x:351.45,y:400.5,regX:10.1,regY:12.7}}]},1).to({state:[{t:this.ikNode_27,p:{regX:11.8,rotation:1.1556,x:243.55,y:358.8}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9988,rotation:64.762,x:335.35,y:317.85,scaleY:0.9988,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9987,scaleY:0.9987,rotation:-94.7873,x:310.3,y:276.25,regX:94.9,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-64.8614,x:296.7,y:207.55,regY:22.2,regX:154.8}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9991,scaleY:0.9991,rotation:-22.2796,x:158.55,y:325.6,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:50.4372,x:318.9,y:331.85,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.8,scaleX:0.9994,scaleY:0.9994,rotation:1.1566,x:244.85,y:317.5}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.1556,x:245.8,y:266.5,regY:128.6,regX:121.2}},{t:this.instance_6,p:{regX:37.5,scaleX:0.9992,scaleY:0.9992,rotation:-2.5663,x:219,y:147.8,startPosition:18,regY:150.2}},{t:this.ikNode_31,p:{regX:5.7,regY:9.6,scaleX:0.9991,scaleY:0.9991,rotation:103.9855,x:255.75,y:-2.6}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.1556,x:192.65,y:162.55,regY:26.9,regX:65.9}},{t:this.instance_4,p:{regX:155.8,scaleX:0.999,scaleY:0.999,rotation:-43.6348,x:165,y:181.1,regY:18.4}},{t:this.ikNode_37,p:{regX:11.7,scaleX:0.9988,scaleY:0.9988,rotation:48.0417,x:377.3,y:366.95,regY:8.6}},{t:this.instance_3,p:{rotation:-52.1299,x:156.3,y:291.55,regX:55.2,scaleX:0.9989,scaleY:0.9989}},{t:this.instance_2,p:{rotation:-61.4625,x:153.1,y:243.9,scaleX:0.9991,scaleY:0.9991,regX:97.7,regY:59.5}},{t:this.ikNode_40,p:{regY:5.6,scaleX:0.9987,scaleY:0.9987,rotation:-35.7935,x:144.55,y:355.65,regX:12.2}},{t:this.instance_1,p:{regX:38.4,regY:10.4,scaleX:0.9992,scaleY:0.9992,rotation:-7.6756,x:175.15,y:373.7}},{t:this.ikNode_44,p:{scaleX:0.9989,scaleY:0.9989,rotation:-168.0678,x:238.85,y:381.75,regY:6.7,regX:9.2}},{t:this.instance,p:{regY:9.3,rotation:34.8834,x:293.25,y:353.5,scaleX:0.9993,scaleY:0.9993,regX:19.8}},{t:this.ikNode_46,p:{scaleX:0.9992,scaleY:0.9992,rotation:-121.3911,x:341.55,y:407.4,regX:10,regY:12.7}}]},1).to({state:[{t:this.ikNode_27,p:{regX:11.8,rotation:1.1451,x:243.45,y:356.85}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9989,rotation:74.4872,x:325.75,y:319.05,scaleY:0.9989,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9986,scaleY:0.9986,rotation:-88.811,x:305.25,y:275.1,regX:94.9,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-60.7337,x:296.5,y:205.55,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.5,scaleX:0.9992,scaleY:0.9992,rotation:-16.5118,x:158.55,y:323.65,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:52.7557,x:318.8,y:329.8,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.1452,x:244.75,y:315.6}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.1452,x:245.7,y:264.45,regY:128.6,regX:121.2}},{t:this.instance_6,p:{regX:37.5,scaleX:0.9992,scaleY:0.9992,rotation:-1.5988,x:218.9,y:145.95,startPosition:19,regY:150.2}},{t:this.ikNode_31,p:{regX:5.6,regY:9.6,scaleX:0.9991,scaleY:0.9991,rotation:104.9688,x:258.25,y:-4}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.1452,x:192.6,y:160.4,regY:26.8,regX:65.9}},{t:this.instance_4,p:{regX:155.9,scaleX:0.999,scaleY:0.999,rotation:-47.5559,x:164.95,y:179.1,regY:18.4}},{t:this.ikNode_37,p:{regX:11.7,scaleX:0.9988,scaleY:0.9988,rotation:25.2089,x:359,y:374.4,regY:8.6}},{t:this.instance_3,p:{rotation:-56.7226,x:163.7,y:289.95,regX:55.2,scaleX:0.9989,scaleY:0.9989}},{t:this.instance_2,p:{rotation:-65.3181,x:157.3,y:242.6,scaleX:0.9991,scaleY:0.9991,regX:97.7,regY:59.6}},{t:this.ikNode_40,p:{regY:5.7,scaleX:0.9987,scaleY:0.9987,rotation:-40.1061,x:157.1,y:354.8,regX:12.3}},{t:this.instance_1,p:{regX:38.3,regY:10.3,scaleX:0.9992,scaleY:0.9992,rotation:-6.8842,x:170.05,y:372.95}},{t:this.ikNode_44,p:{scaleX:0.9989,scaleY:0.9989,rotation:-169.8532,x:233.8,y:382.1,regY:6.7,regX:9.2}},{t:this.instance,p:{regY:9.3,rotation:45.5005,x:292.25,y:350.55,scaleX:0.9993,scaleY:0.9993,regX:19.8}},{t:this.ikNode_46,p:{scaleX:0.9992,scaleY:0.9992,rotation:-80.287,x:329.9,y:412.45,regX:10,regY:12.7}}]},1).to({state:[{t:this.ikNode_27,p:{regX:11.8,rotation:1.1451,x:243.55,y:359.2}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9989,rotation:78.6118,x:313.85,y:324.25,scaleY:0.9989,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9986,scaleY:0.9986,rotation:-81.4754,x:299.1,y:278.05,regX:94.8,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-55.6915,x:296.7,y:207.85,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-13.3236,x:158.6,y:326.1,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:39.5659,x:319.05,y:332.15,regY:17.7}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.1452,x:244.85,y:318}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.1452,x:245.8,y:266.85,regY:128.6,regX:121.2}},{t:this.instance_6,p:{regX:37.5,scaleX:0.9992,scaleY:0.9992,rotation:-2.7678,x:219.05,y:148.25,startPosition:20,regY:150.2}},{t:this.ikNode_31,p:{regX:5.7,regY:9.6,scaleX:0.9991,scaleY:0.9991,rotation:103.7988,x:255.2,y:-2.3}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.1452,x:192.6,y:162.75,regY:26.8,regX:65.9}},{t:this.instance_4,p:{regX:155.8,scaleX:0.999,scaleY:0.999,rotation:-52.2551,x:165.1,y:181.5,regY:18.4}},{t:this.ikNode_37,p:{regX:11.7,scaleX:0.9988,scaleY:0.9988,rotation:31.7409,x:343.05,y:382,regY:8.6}},{t:this.instance_3,p:{rotation:-62.2231,x:172.85,y:292.05,regX:55.2,scaleX:0.9989,scaleY:0.9989}},{t:this.instance_2,p:{rotation:-69.9017,x:162.65,y:245.55,scaleX:0.9991,scaleY:0.9991,regX:97.6,regY:59.5}},{t:this.ikNode_40,p:{regY:5.7,scaleX:0.9988,scaleY:0.9988,rotation:-45.3782,x:172.65,y:357.25,regX:12.3}},{t:this.instance_1,p:{regX:38.3,regY:10.3,scaleX:0.9992,scaleY:0.9992,rotation:-6.6525,x:167.4,y:376}},{t:this.ikNode_44,p:{scaleX:0.9989,scaleY:0.9989,rotation:158.995,x:231.05,y:385.3,regY:6.7,regX:9.2}},{t:this.instance,p:{regY:9.3,rotation:34.0654,x:297.8,y:358.4,scaleX:0.9993,scaleY:0.9993,regX:19.8}},{t:this.ikNode_46,p:{scaleX:0.9992,scaleY:0.9992,rotation:-105.0995,x:346.9,y:411.6,regX:10,regY:12.7}}]},1).to({state:[{t:this.ikNode_27,p:{regX:11.8,rotation:1.1451,x:243.6,y:361.55}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9989,rotation:82.737,x:301.75,y:328.2,scaleY:0.9989,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9986,scaleY:0.9986,rotation:-74.1423,x:293,y:280.25,regX:94.9,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-50.6505,x:296.75,y:210.2,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-10.1364,x:158.6,y:328.6,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:26.3756,x:319.15,y:334.6,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.1452,x:244.9,y:320.4}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.1452,x:245.9,y:269.25,regY:128.6,regX:121.2}},{t:this.instance_6,p:{regX:37.5,scaleX:0.9992,scaleY:0.9992,rotation:-3.9379,x:219.15,y:150.55,startPosition:21,regY:150.2}},{t:this.ikNode_31,p:{regX:5.7,regY:9.6,scaleX:0.9991,scaleY:0.9991,rotation:102.6286,x:252.15,y:-0.75}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.1452,x:192.65,y:165.15,regY:26.8,regX:65.9}},{t:this.instance_4,p:{regX:155.9,scaleX:0.999,scaleY:0.999,rotation:-56.9534,x:165.25,y:183.7,regY:18.4}},{t:this.ikNode_37,p:{regX:11.7,scaleX:0.9988,scaleY:0.9988,rotation:38.2732,x:326.5,y:387.9,regY:8.6}},{t:this.instance_3,p:{rotation:-67.7237,x:181.9,y:293.4,regX:55.2,scaleX:0.9989,scaleY:0.9989}},{t:this.instance_2,p:{rotation:-74.4866,x:168.25,y:247.65,scaleX:0.9991,scaleY:0.9991,regX:97.7,regY:59.6}},{t:this.ikNode_40,p:{regY:5.6,scaleX:0.9987,scaleY:0.9987,rotation:-50.6492,x:187.95,y:358.3,regX:12.3}},{t:this.instance_1,p:{regX:38.3,regY:10.4,scaleX:0.9992,scaleY:0.9992,rotation:-6.4217,x:164.7,y:379}},{t:this.ikNode_44,p:{scaleX:0.9989,scaleY:0.9989,rotation:127.839,x:228.35,y:388.4,regY:6.7,regX:9.2}},{t:this.instance,p:{regY:9.3,rotation:22.6308,x:304.25,y:364.95,scaleX:0.9994,scaleY:0.9994,regX:19.7}},{t:this.ikNode_46,p:{scaleX:0.9992,scaleY:0.9992,rotation:-129.9182,x:362.9,y:407.35,regX:10,regY:12.7}}]},1).to({state:[{t:this.ikNode_27,p:{regX:11.8,rotation:1.1451,x:243.7,y:363.95}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9989,rotation:86.8633,x:289.35,y:330.7,scaleY:0.9989,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9986,scaleY:0.9986,rotation:-66.8064,x:286.95,y:281.95,regX:94.9,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-45.6079,x:296.9,y:212.55,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.5,scaleX:0.9992,scaleY:0.9992,rotation:-6.947,x:158.55,y:331.15,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:13.1845,x:319.3,y:337,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.1452,x:245,y:322.75}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.1452,x:246,y:271.65,regY:128.6,regX:121.2}},{t:this.instance_6,p:{regX:37.4,scaleX:0.9992,scaleY:0.9992,rotation:-5.1079,x:219.1,y:153,startPosition:22,regY:150.2}},{t:this.ikNode_31,p:{regX:5.7,regY:9.6,scaleX:0.9991,scaleY:0.9991,rotation:101.4591,x:249,y:1.05}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.1452,x:192.7,y:167.5,regY:26.8,regX:65.9}},{t:this.instance_4,p:{regX:155.8,scaleX:0.999,scaleY:0.999,rotation:-61.6516,x:165.35,y:186.15,regY:18.4}},{t:this.ikNode_37,p:{regX:11.7,scaleX:0.9988,scaleY:0.9988,rotation:44.8057,x:309.8,y:392.25,regY:8.6}},{t:this.instance_3,p:{rotation:-73.2259,x:190.95,y:294,regX:55.2,scaleX:0.9989,scaleY:0.9989}},{t:this.instance_2,p:{rotation:-79.0697,x:173.65,y:249.55,scaleX:0.9991,scaleY:0.9991,regX:97.7,regY:59.6}},{t:this.ikNode_40,p:{regY:5.6,scaleX:0.9988,scaleY:0.9988,rotation:-55.922,x:203.3,y:358,regX:12.3}},{t:this.instance_1,p:{regX:38.3,regY:10.4,scaleX:0.9992,scaleY:0.9992,rotation:-6.1895,x:162,y:381.65}},{t:this.ikNode_44,p:{scaleX:0.9989,scaleY:0.9989,rotation:96.6843,x:225.7,y:391.35,regY:6.7,regX:9.2}},{t:this.instance,p:{regY:9.3,rotation:11.1946,x:311.75,y:369.85,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_46,p:{scaleX:0.9992,scaleY:0.9992,rotation:-154.7361,x:377.3,y:399.8,regX:10.1,regY:12.7}}]},1).to({state:[{t:this.ikNode_27,p:{regX:11.8,rotation:1.1451,x:243.8,y:366.3}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9989,rotation:90.9838,x:277.05,y:331.9,scaleY:0.9989,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9986,scaleY:0.9986,rotation:-59.4735,x:280.95,y:283.05,regX:94.9,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-40.5657,x:297,y:214.85,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.5,scaleX:0.9992,scaleY:0.9992,rotation:-3.759,x:158.5,y:333.7,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-0.0018,x:319.4,y:339.4,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.1452,x:245.1,y:325.15}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.1452,x:246.1,y:274.05,regY:128.6,regX:121.2}},{t:this.instance_6,p:{regX:37.5,scaleX:0.9992,scaleY:0.9992,rotation:-6.2784,x:219.35,y:155.3,startPosition:23,regY:150.2}},{t:this.ikNode_31,p:{regX:5.7,regY:9.6,scaleX:0.9991,scaleY:0.9991,rotation:100.2891,x:246,y:2.8}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.1452,x:192.75,y:169.85,regY:26.8,regX:65.9}},{t:this.instance_4,p:{regX:155.9,scaleX:0.999,scaleY:0.999,rotation:-66.3503,x:165.7,y:188.45,regY:18.5}},{t:this.ikNode_37,p:{regX:11.7,scaleX:0.9988,scaleY:0.9988,rotation:51.3368,x:292.95,y:394.75,regY:8.6}},{t:this.instance_3,p:{rotation:-78.7249,x:199.85,y:293.9,regX:55.2,scaleX:0.9989,scaleY:0.9989}},{t:this.instance_2,p:{rotation:-83.655,x:179.15,y:251.2,scaleX:0.9991,scaleY:0.9991,regX:97.6,regY:59.6}},{t:this.ikNode_40,p:{regY:5.6,scaleX:0.9988,scaleY:0.9988,rotation:-61.192,x:218.25,y:356.45,regX:12.2}},{t:this.instance_1,p:{regX:38.3,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.9579,x:159.35,y:384.35}},{t:this.ikNode_44,p:{scaleX:0.9989,scaleY:0.9989,rotation:65.5329,x:223,y:394.2,regY:6.7,regX:9.2}},{t:this.instance,p:{regY:9.3,rotation:-0.2345,x:319.55,y:373.15,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_46,p:{scaleX:0.9992,scaleY:0.9992,rotation:-179.5555,x:389.7,y:389.4,regX:10,regY:12.8}}]},1).to({state:[{t:this.ikNode_27,p:{regX:11.8,rotation:1.1451,x:243.85,y:368.6}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9989,rotation:95.1103,x:264.9,y:331.75,scaleY:0.9989,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9986,scaleY:0.9986,rotation:-52.1388,x:275.05,y:283.7,regX:94.9,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-35.5226,x:297.15,y:217.3,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.5705,x:158.6,y:336.2,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-13.1922,x:319.55,y:341.7,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.1452,x:245.2,y:327.45}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.1452,x:246.2,y:276.35,regY:128.6,regX:121.2}},{t:this.instance_6,p:{regX:37.5,scaleX:0.9992,scaleY:0.9992,rotation:-7.4459,x:219.55,y:157.75,startPosition:24,regY:150.2}},{t:this.ikNode_31,p:{regX:5.7,regY:9.6,scaleX:0.9991,scaleY:0.9991,rotation:99.1198,x:242.95,y:4.45}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.1452,x:192.75,y:172.15,regY:26.8,regX:65.9}},{t:this.instance_4,p:{regX:155.9,scaleX:0.999,scaleY:0.999,rotation:-71.0475,x:165.9,y:190.65,regY:18.5}},{t:this.ikNode_37,p:{regX:11.7,scaleX:0.9988,scaleY:0.9988,rotation:57.8682,x:276.15,y:395.7,regY:8.6}},{t:this.instance_3,p:{rotation:-84.2253,x:208.5,y:293,regX:55.2,scaleX:0.999,scaleY:0.999}},{t:this.instance_2,p:{rotation:-88.2373,x:184.4,y:252.15,scaleX:0.9991,scaleY:0.9991,regX:97.6,regY:59.6}},{t:this.ikNode_40,p:{regY:5.7,scaleX:0.9988,scaleY:0.9988,rotation:-66.4628,x:233.05,y:353.5,regX:12.3}},{t:this.instance_1,p:{regX:38.4,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.7284,x:156.8,y:386.7}},{t:this.ikNode_44,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.377,x:220.4,y:396.8,regY:6.7,regX:9.2}},{t:this.instance,p:{regY:9.3,rotation:-11.6704,x:327.35,y:374.6,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_46,p:{scaleX:0.9992,scaleY:0.9992,rotation:155.6322,x:399.3,y:376.8,regX:10,regY:12.7}}]},1).to({state:[{t:this.ikNode_67,p:{regX:11.7,rotation:1.2807,x:243.45,y:368.4}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9988,rotation:44.698,x:400.4,y:272.5,scaleY:0.9988,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9986,scaleY:0.9986,rotation:-139.1129,x:353,y:259.9,regX:94.9,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-106.428,x:297.4,y:217.3,regY:22.1,regX:154.9}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.4699,x:158.75,y:336,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-8.6289,x:319.6,y:341.95,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.8,scaleX:0.9994,scaleY:0.9994,rotation:1.2852,x:245.3,y:327.4}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2834,x:246.25,y:276.4,regY:128.7,regX:121.2}},{t:this.instance_6,p:{regX:37.6,scaleX:0.9992,scaleY:0.9992,rotation:-7.3763,x:220.15,y:157.65,startPosition:1,regY:150.3}},{t:this.ikNode_71,p:{scaleX:0.9991,scaleY:0.9991,rotation:99.0161,x:243.55,y:4.25,regX:5.7,regY:9.6}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2834,x:193.1,y:172.1,regY:26.9,regX:65.9}},{t:this.instance_4,p:{regX:155.9,scaleX:0.999,scaleY:0.999,rotation:-18.9256,x:166.1,y:190.6,regY:18.6}},{t:this.ikNode_80,p:{scaleX:0.9988,scaleY:0.9988,rotation:7.2574,x:457,y:304.7,regY:8.6}},{t:this.instance_3,p:{rotation:-36.9544,x:110.6,y:286.7,regX:55.1,scaleX:0.9989,scaleY:0.9989}},{t:this.instance_2,p:{rotation:-35.0125,x:129.05,y:242.85,scaleX:0.9991,scaleY:0.9991,regX:97.6,regY:59.6}},{t:this.ikNode_76,p:{regX:12.4,regY:5.6,scaleX:0.9988,scaleY:0.9988,rotation:76.5262,x:82.9,y:345.85}},{t:this.instance_1,p:{regX:38.3,regY:10.4,scaleX:0.9992,scaleY:0.9992,rotation:-5.4828,x:156.65,y:386.4}},{t:this.ikNode_83,p:{scaleX:0.999,scaleY:0.999,rotation:34.3644,x:220.35,y:396.8}},{t:this.instance,p:{regY:9.3,rotation:-0.4024,x:324.7,y:375.3,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_86,p:{regY:12.7,scaleX:0.9993,scaleY:0.9993,rotation:4.2288,x:394.9,y:391.55}}]},1).to({state:[{t:this.ikNode_67,p:{regX:11.8,rotation:1.279,x:243.5,y:368.35}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9988,rotation:42.4862,x:401.4,y:269.8,scaleY:0.9988,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9985,scaleY:0.9985,rotation:-140.2568,x:353.7,y:258.2,regX:94.8,regY:63.4}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-108.0435,x:296.9,y:217.05,regY:22.1,regX:154.9}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.469,x:158.65,y:335.95,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-8.6287,x:319.55,y:341.85,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2844,x:245.25,y:327.45}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.0236,x:246.1,y:276.35,regY:128.7,regX:121.3}},{t:this.instance_6,p:{regX:37.6,scaleX:0.9991,scaleY:0.9991,rotation:-8.3407,x:219.35,y:157.6,startPosition:2,regY:150.3}},{t:this.ikNode_71,p:{scaleX:0.999,scaleY:0.999,rotation:98.0514,x:240.2,y:4.1,regX:5.7,regY:9.6}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.0236,x:192.4,y:172.45,regY:27,regX:65.9}},{t:this.instance_4,p:{regX:155.8,scaleX:0.9989,scaleY:0.9989,rotation:-18.9226,x:165.4,y:190.9,regY:18.6}},{t:this.ikNode_80,p:{scaleX:0.9987,scaleY:0.9987,rotation:5.0443,x:459.2,y:299.8,regY:8.6}},{t:this.instance_3,p:{rotation:-35.7216,x:108.45,y:286.4,regX:55.1,scaleX:0.9988,scaleY:0.9988}},{t:this.instance_2,p:{rotation:-32.9568,x:128.4,y:243.3,scaleX:0.999,scaleY:0.999,regX:97.6,regY:59.6}},{t:this.ikNode_76,p:{regX:12.5,regY:5.5,scaleX:0.9987,scaleY:0.9987,rotation:77.7586,x:79.55,y:344.9}},{t:this.instance_1,p:{regX:38.4,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.4821,x:156.7,y:386.45}},{t:this.ikNode_83,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.3642,x:220.25,y:396.75}},{t:this.instance,p:{regY:9.3,rotation:-0.4015,x:324.65,y:375.25,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_86,p:{regY:12.8,scaleX:0.9992,scaleY:0.9992,rotation:4.2282,x:394.85,y:391.6}}]},1).to({state:[{t:this.ikNode_67,p:{regX:11.8,rotation:1.279,x:243.5,y:368.35}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9988,rotation:40.2739,x:402.25,y:267,scaleY:0.9988,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9985,scaleY:0.9985,rotation:-141.4019,x:354.35,y:256.3,regX:94.8,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-109.6588,x:296.5,y:216.9,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.469,x:158.65,y:335.95,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-8.6286,x:319.55,y:341.85,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2844,x:245.25,y:327.45}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:0.7629,x:245.9,y:276.35,regY:128.7,regX:121.3}},{t:this.instance_6,p:{regX:37.6,scaleX:0.9991,scaleY:0.9991,rotation:-9.3058,x:218.55,y:157.9,startPosition:3,regY:150.4}},{t:this.ikNode_71,p:{scaleX:0.999,scaleY:0.999,rotation:97.0864,x:236.85,y:3.75,regX:5.6,regY:9.6}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:0.7629,x:191.7,y:172.7,regY:27,regX:65.9}},{t:this.instance_4,p:{regX:155.8,scaleX:0.9989,scaleY:0.9989,rotation:-18.9198,x:164.75,y:191.25,regY:18.6}},{t:this.ikNode_80,p:{scaleX:0.9987,scaleY:0.9987,rotation:2.8321,x:461.05,y:294.85,regY:8.7}},{t:this.instance_3,p:{rotation:-34.4888,x:106.2,y:286.05,regX:55.1,scaleX:0.9988,scaleY:0.9988}},{t:this.instance_2,p:{rotation:-30.9019,x:127.8,y:243.7,scaleX:0.999,scaleY:0.999,regX:97.6,regY:59.6}},{t:this.ikNode_76,p:{regX:12.4,regY:5.7,scaleX:0.9987,scaleY:0.9987,rotation:78.9921,x:75.85,y:343.85}},{t:this.instance_1,p:{regX:38.4,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.4821,x:156.7,y:386.45}},{t:this.ikNode_83,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.3642,x:220.25,y:396.75}},{t:this.instance,p:{regY:9.3,rotation:-0.4007,x:324.65,y:375.25,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_86,p:{regY:12.8,scaleX:0.9992,scaleY:0.9992,rotation:4.2282,x:394.85,y:391.6}}]},1).to({state:[{t:this.ikNode_67,p:{regX:11.8,rotation:1.2781,x:243.55,y:368.35}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9988,rotation:38.0618,x:403.1,y:264.15,scaleY:0.9988,regX:12.3}},{t:this.instance_12,p:{scaleX:0.9985,scaleY:0.9985,rotation:-142.5452,x:354.95,y:254.4,regX:94.8,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9985,scaleY:0.9985,rotation:-111.2759,x:295.9,y:216.5,regY:22.1,regX:154.9}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.469,x:158.65,y:335.95,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-8.6286,x:319.55,y:341.85,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2844,x:245.25,y:327.45}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:0.503,x:245.5,y:276.25,regY:128.7,regX:121.2}},{t:this.instance_6,p:{regX:37.6,scaleX:0.9991,scaleY:0.9991,rotation:-10.2703,x:217.75,y:157.85,startPosition:4,regY:150.3}},{t:this.ikNode_71,p:{scaleX:0.999,scaleY:0.999,rotation:96.1217,x:233.45,y:3.65,regX:5.7,regY:9.6}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:0.503,x:190.95,y:172.85,regY:27,regX:65.9}},{t:this.instance_4,p:{regX:155.8,scaleX:0.9989,scaleY:0.9989,rotation:-18.9187,x:164.15,y:191.6,regY:18.6}},{t:this.ikNode_80,p:{scaleX:0.9988,scaleY:0.9988,rotation:0.6198,x:462.95,y:289.75,regY:8.7}},{t:this.instance_3,p:{rotation:-33.257,x:104.05,y:285.6,regX:55.1,scaleX:0.9988,scaleY:0.9988}},{t:this.instance_2,p:{rotation:-28.8467,x:127.2,y:243.95,scaleX:0.999,scaleY:0.999,regX:97.7,regY:59.6}},{t:this.ikNode_76,p:{regX:12.5,regY:5.6,scaleX:0.9987,scaleY:0.9987,rotation:80.2249,x:72.65,y:342.85}},{t:this.instance_1,p:{regX:38.4,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.4821,x:156.7,y:386.45}},{t:this.ikNode_83,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.3642,x:220.25,y:396.75}},{t:this.instance,p:{regY:9.3,rotation:-0.4007,x:324.65,y:375.25,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_86,p:{regY:12.8,scaleX:0.9992,scaleY:0.9992,rotation:4.2273,x:394.85,y:391.65}}]},1).to({state:[{t:this.ikNode_67,p:{regX:11.8,rotation:1.2781,x:243.55,y:368.35}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9988,rotation:35.8476,x:403.75,y:261.25,scaleY:0.9988,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9985,scaleY:0.9985,rotation:-143.6903,x:355.4,y:252.55,regX:94.8,regY:63.4}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-112.8914,x:295.5,y:216.25,regY:22.2,regX:154.9}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.4681,x:158.65,y:335.95,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-8.6286,x:319.55,y:341.85,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2835,x:245.25,y:327.45}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:0.2423,x:245.3,y:276.25,regY:128.7,regX:121.2}},{t:this.instance_6,p:{regX:37.6,scaleX:0.9991,scaleY:0.9991,rotation:-11.2349,x:217,y:158.15,startPosition:5,regY:150.4}},{t:this.ikNode_71,p:{scaleX:0.999,scaleY:0.999,rotation:95.1553,x:230.05,y:3.55,regX:5.7,regY:9.6}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:0.2423,x:190.25,y:173.1,regY:27,regX:65.9}},{t:this.instance_4,p:{regX:155.8,scaleX:0.9989,scaleY:0.9989,rotation:-18.916,x:163.55,y:192,regY:18.7}},{t:this.ikNode_80,p:{scaleX:0.9987,scaleY:0.9987,rotation:-1.589,x:464.6,y:284.4,regY:8.6}},{t:this.instance_3,p:{rotation:-32.024,x:101.95,y:285.1,regX:55.1,scaleX:0.9988,scaleY:0.9988}},{t:this.instance_2,p:{rotation:-26.7913,x:126.6,y:244.3,scaleX:0.999,scaleY:0.999,regX:97.7,regY:59.6}},{t:this.ikNode_76,p:{regX:12.5,regY:5.6,scaleX:0.9987,scaleY:0.9987,rotation:81.4574,x:69.25,y:341.65}},{t:this.instance_1,p:{regX:38.4,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.4813,x:156.7,y:386.45}},{t:this.ikNode_83,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.3642,x:220.25,y:396.75}},{t:this.instance,p:{regY:9.3,rotation:-0.4007,x:324.65,y:375.25,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_86,p:{regY:12.8,scaleX:0.9992,scaleY:0.9992,rotation:4.2273,x:394.85,y:391.6}}]},1).to({state:[{t:this.ikNode_67,p:{regX:11.8,rotation:1.2781,x:243.55,y:368.35}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9988,rotation:33.6352,x:404.45,y:258.3,scaleY:0.9988,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9985,scaleY:0.9985,rotation:-144.8333,x:355.95,y:250.5,regX:94.8,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-114.5086,x:295,y:215.95,regY:22.2,regX:154.9}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.4681,x:158.65,y:335.95,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-8.6286,x:319.55,y:341.85,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2835,x:245.25,y:327.45}},{t:this.instance_7,p:{scaleX:0.9993,scaleY:0.9993,rotation:-0.0131,x:245.15,y:276.3,regY:128.7,regX:121.3}},{t:this.instance_6,p:{regX:37.6,scaleX:0.9991,scaleY:0.9991,rotation:-12.1999,x:216.25,y:158.1,startPosition:6,regY:150.3}},{t:this.ikNode_71,p:{scaleX:0.999,scaleY:0.999,rotation:94.1904,x:226.8,y:3.45,regX:5.7,regY:9.5}},{t:this.instance_5,p:{scaleX:0.9993,scaleY:0.9993,rotation:-0.0131,x:189.5,y:173.4,regY:27,regX:65.9}},{t:this.instance_4,p:{regX:155.8,scaleX:0.999,scaleY:0.999,rotation:-18.9121,x:162.85,y:192.4,regY:18.7}},{t:this.ikNode_80,p:{scaleX:0.9988,scaleY:0.9988,rotation:-3.8019,x:466.05,y:279.05,regY:8.6}},{t:this.instance_3,p:{rotation:-30.7913,x:99.95,y:284.6,regX:55.1,scaleX:0.9988,scaleY:0.9988}},{t:this.instance_2,p:{rotation:-24.7358,x:125.85,y:244.75,scaleX:0.999,scaleY:0.999,regX:97.6,regY:59.6}},{t:this.ikNode_76,p:{regX:12.5,regY:5.6,scaleX:0.9987,scaleY:0.9987,rotation:82.6905,x:66,y:340.4}},{t:this.instance_1,p:{regX:38.4,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.4813,x:156.7,y:386.45}},{t:this.ikNode_83,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.3642,x:220.25,y:396.75}},{t:this.instance,p:{regY:9.3,rotation:-0.3998,x:324.65,y:375.25,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_86,p:{regY:12.8,scaleX:0.9992,scaleY:0.9992,rotation:4.2273,x:394.85,y:391.6}}]},1).to({state:[{t:this.ikNode_67,p:{regX:11.8,rotation:1.2781,x:243.55,y:368.35}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9988,rotation:31.4237,x:404.95,y:255.3,scaleY:0.9988,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9985,scaleY:0.9985,rotation:-145.9782,x:356.45,y:248.6,regX:94.8,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-116.1246,x:294.4,y:215.8,regY:22.1,regX:154.9}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.4673,x:158.65,y:335.95,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-8.6277,x:319.55,y:341.85,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2835,x:245.25,y:327.45}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:-0.2729,x:244.8,y:276.3,regY:128.7,regX:121.2}},{t:this.instance_6,p:{regX:37.6,scaleX:0.9991,scaleY:0.9991,rotation:-13.1642,x:215.5,y:158.2,startPosition:7,regY:150.3}},{t:this.ikNode_71,p:{scaleX:0.999,scaleY:0.999,rotation:93.2256,x:223.3,y:3.4,regX:5.7,regY:9.6}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:-0.2729,x:188.9,y:173.65,regY:27,regX:65.9}},{t:this.instance_4,p:{regX:155.8,scaleX:0.9989,scaleY:0.9989,rotation:-18.9093,x:162.2,y:192.7,regY:18.6}},{t:this.ikNode_80,p:{scaleX:0.9988,scaleY:0.9988,rotation:-6.0152,x:467.4,y:273.8,regY:8.6}},{t:this.instance_3,p:{rotation:-29.5581,x:97.8,y:283.95,regX:55.1,scaleX:0.9989,scaleY:0.9989}},{t:this.instance_2,p:{rotation:-22.6807,x:125.25,y:245.1,scaleX:0.999,scaleY:0.999,regX:97.6,regY:59.6}},{t:this.ikNode_76,p:{regX:12.5,regY:5.6,scaleX:0.9987,scaleY:0.9987,rotation:83.9228,x:62.8,y:339.1}},{t:this.instance_1,p:{regX:38.4,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.4813,x:156.7,y:386.45}},{t:this.ikNode_83,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.3647,x:220.25,y:396.75}},{t:this.instance,p:{regY:9.3,rotation:-0.3998,x:324.65,y:375.25,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_86,p:{regY:12.8,scaleX:0.9992,scaleY:0.9992,rotation:4.2273,x:394.85,y:391.6}}]},1).to({state:[{t:this.ikNode_67,p:{regX:11.8,rotation:1.2772,x:243.55,y:368.35}},{t:this.instance_13,p:{regY:38.8,scaleX:0.9988,rotation:29.2099,x:405.6,y:252.25,scaleY:0.9988,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9985,scaleY:0.9985,rotation:-147.1225,x:356.75,y:246.55,regX:94.8,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-117.7417,x:293.95,y:215.7,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.4673,x:158.65,y:335.95,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-8.6277,x:319.55,y:341.9,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2826,x:245.3,y:327.45}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:-0.5337,x:244.7,y:276.3,regY:128.7,regX:121.3}},{t:this.instance_6,p:{regX:37.6,scaleX:0.9991,scaleY:0.9991,rotation:-14.1296,x:214.75,y:158.35,startPosition:8,regY:150.3}},{t:this.ikNode_71,p:{scaleX:0.9991,scaleY:0.9991,rotation:92.261,x:219.9,y:3.4,regX:5.7,regY:9.6}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:-0.5337,x:188.1,y:173.9,regY:27,regX:65.9}},{t:this.instance_4,p:{regX:155.8,scaleX:0.9989,scaleY:0.9989,rotation:-18.9068,x:161.55,y:193.05,regY:18.6}},{t:this.ikNode_80,p:{scaleX:0.9987,scaleY:0.9987,rotation:-8.2279,x:468.6,y:268.4,regY:8.6}},{t:this.instance_3,p:{rotation:-28.3268,x:95.85,y:283.3,regX:55.1,scaleX:0.9989,scaleY:0.9989}},{t:this.instance_2,p:{rotation:-20.6246,x:124.6,y:245.45,scaleX:0.999,scaleY:0.999,regX:97.6,regY:59.6}},{t:this.ikNode_76,p:{regX:12.5,regY:5.6,scaleX:0.9987,scaleY:0.9987,rotation:85.1557,x:59.65,y:337.65}},{t:this.instance_1,p:{regX:38.4,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.4813,x:156.75,y:386.45}},{t:this.ikNode_83,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.3647,x:220.2,y:396.75}},{t:this.instance,p:{regY:9.3,rotation:-0.3998,x:324.65,y:375.25,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_86,p:{regY:12.8,scaleX:0.9992,scaleY:0.9992,rotation:4.2273,x:394.85,y:391.6}}]},1).to({state:[{t:this.ikNode_67,p:{regX:11.8,rotation:1.2772,x:243.55,y:368.35}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9988,rotation:30.602,x:406.55,y:256.65,scaleY:0.9988,regX:12.3}},{t:this.instance_12,p:{scaleX:0.9985,scaleY:0.9985,rotation:-145.4867,x:357.95,y:249.4,regX:94.8,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-116.02,x:296.05,y:216.5,regY:22.2,regX:154.9}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.4673,x:158.65,y:335.95,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-8.6277,x:319.5,y:341.85,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2826,x:245.3,y:327.45}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:0.5547,x:245.65,y:276.3,regY:128.7,regX:121.3}},{t:this.instance_6,p:{regX:37.6,scaleX:0.9991,scaleY:0.9991,rotation:-13.2938,x:217.95,y:157.8,startPosition:9,regY:150.3}},{t:this.ikNode_71,p:{scaleX:0.9991,scaleY:0.9991,rotation:93.0959,x:225.35,y:3,regX:5.7,regY:9.6}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:0.5547,x:191.1,y:172.85,regY:27,regX:65.9}},{t:this.instance_4,p:{regX:155.8,scaleX:0.999,scaleY:0.999,rotation:-18.4695,x:164.15,y:191.55,regY:18.6}},{t:this.ikNode_80,p:{scaleX:0.9987,scaleY:0.9987,rotation:-6.8372,x:469.1,y:274.2,regY:8.6}},{t:this.instance_3,p:{rotation:-30.8525,x:99.15,y:282.35,regX:55.1,scaleX:0.9988,scaleY:0.9988}},{t:this.instance_2,p:{rotation:-22.3923,x:126.8,y:243.6,scaleX:0.999,scaleY:0.999,regX:97.6,regY:59.6}},{t:this.ikNode_76,p:{regX:12.5,regY:5.6,scaleX:0.9987,scaleY:0.9987,rotation:75.5075,x:65.45,y:338.3}},{t:this.instance_1,p:{regX:38.4,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.4813,x:156.75,y:386.4}},{t:this.ikNode_83,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.3647,x:220.2,y:396.75}},{t:this.instance,p:{regY:9.3,rotation:-0.3998,x:324.65,y:375.25,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_86,p:{regY:12.8,scaleX:0.9992,scaleY:0.9992,rotation:4.2264,x:394.85,y:391.6}}]},1).to({state:[{t:this.ikNode_67,p:{regX:11.8,rotation:1.2772,x:243.55,y:368.35}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9988,rotation:31.9914,x:407.35,y:260.85,scaleY:0.9988,regX:12.3}},{t:this.instance_12,p:{scaleX:0.9985,scaleY:0.9985,rotation:-143.8502,x:358.95,y:252.2,regX:94.9,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9985,scaleY:0.9985,rotation:-114.2985,x:298.05,y:217.5,regY:22.1,regX:154.9}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.4673,x:158.65,y:335.9,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-8.6277,x:319.5,y:341.85,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2826,x:245.3,y:327.45}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.6467,x:246.6,y:276.4,regY:128.7,regX:121.3}},{t:this.instance_6,p:{regX:37.6,scaleX:0.9991,scaleY:0.9991,rotation:-12.459,x:221.2,y:157.5,startPosition:10,regY:150.4}},{t:this.ikNode_71,p:{scaleX:0.999,scaleY:0.999,rotation:93.9297,x:230.85,y:2.6,regX:5.7,regY:9.6}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.6467,x:194.05,y:171.75,regY:26.9,regX:66}},{t:this.instance_4,p:{regX:155.8,scaleX:0.999,scaleY:0.999,rotation:-18.0328,x:166.7,y:190.05,regY:18.6}},{t:this.ikNode_80,p:{scaleX:0.9987,scaleY:0.9987,rotation:-5.4461,x:469.55,y:279.9,regY:8.6}},{t:this.instance_3,p:{rotation:-33.3788,x:102.55,y:281.4,regX:55.1,scaleX:0.9988,scaleY:0.9988}},{t:this.instance_2,p:{rotation:-24.1589,x:128.95,y:241.75,scaleX:0.999,scaleY:0.999,regX:97.6,regY:59.6}},{t:this.ikNode_76,p:{regX:12.5,regY:5.6,scaleX:0.9987,scaleY:0.9987,rotation:65.8567,x:71.4,y:338.7}},{t:this.instance_1,p:{regX:38.4,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.4813,x:156.75,y:386.4}},{t:this.ikNode_83,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.3647,x:220.2,y:396.75}},{t:this.instance,p:{regY:9.3,rotation:-0.3998,x:324.65,y:375.25,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_86,p:{regY:12.8,scaleX:0.9992,scaleY:0.9992,rotation:4.2264,x:394.85,y:391.6}}]},1).to({state:[{t:this.ikNode_67,p:{regX:11.8,rotation:1.2772,x:243.55,y:368.35}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9988,rotation:33.3834,x:408.05,y:265.05,scaleY:0.9988,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9985,scaleY:0.9985,rotation:-142.2137,x:360.05,y:255.1,regX:94.8,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-112.5794,x:300.25,y:218.65,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.4673,x:158.65,y:335.9,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-8.6277,x:319.5,y:341.85,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2826,x:245.3,y:327.45}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:2.7393,x:247.6,y:276.4,regY:128.7,regX:121.3}},{t:this.instance_6,p:{regX:37.6,scaleX:0.9991,scaleY:0.9991,rotation:-11.6223,x:224.4,y:157.05,startPosition:11,regY:150.4}},{t:this.ikNode_71,p:{scaleX:0.9991,scaleY:0.9991,rotation:94.7661,x:236.35,y:2.2,regX:5.6,regY:9.6}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:2.7393,x:196.95,y:170.75,regY:26.9,regX:65.9}},{t:this.instance_4,p:{regX:155.8,scaleX:0.999,scaleY:0.999,rotation:-17.5952,x:169.3,y:188.6,regY:18.6}},{t:this.ikNode_80,p:{scaleX:0.9988,scaleY:0.9988,rotation:-4.0555,x:469.85,y:285.55,regY:8.6}},{t:this.instance_3,p:{rotation:-35.9065,x:106.05,y:280.35,regX:55.1,scaleX:0.9988,scaleY:0.9988}},{t:this.instance_2,p:{rotation:-25.9251,x:131.35,y:240.05,scaleX:0.999,scaleY:0.999,regX:97.7,regY:59.6}},{t:this.ikNode_76,p:{regX:12.5,regY:5.6,scaleX:0.9986,scaleY:0.9986,rotation:56.2077,x:77.45,y:338.95}},{t:this.instance_1,p:{regX:38.4,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.4813,x:156.75,y:386.4}},{t:this.ikNode_83,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.363,x:220.2,y:396.75}},{t:this.instance,p:{regY:9.3,rotation:-0.3989,x:324.65,y:375.2,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_86,p:{regY:12.8,scaleX:0.9992,scaleY:0.9992,rotation:4.2264,x:394.85,y:391.6}}]},1).to({state:[{t:this.ikNode_67,p:{regX:11.8,rotation:1.2763,x:243.55,y:368.35}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9988,rotation:34.7739,x:408.75,y:269.2,scaleY:0.9988,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9985,scaleY:0.9985,rotation:-140.5777,x:360.9,y:257.95,regX:94.8,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-110.8577,x:302.2,y:219.6,regY:22.1,regX:154.9}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.4673,x:158.65,y:335.9,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-8.6277,x:319.5,y:341.85,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2826,x:245.3,y:327.45}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:3.8303,x:248.55,y:276.5,regY:128.8,regX:121.3}},{t:this.instance_6,p:{regX:37.6,scaleX:0.9991,scaleY:0.9991,rotation:-10.7875,x:227.65,y:156.5,startPosition:12,regY:150.3}},{t:this.ikNode_71,p:{scaleX:0.999,scaleY:0.999,rotation:95.601,x:241.85,y:1.95,regX:5.6,regY:9.6}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:3.8303,x:199.85,y:169.9,regY:26.9,regX:65.9}},{t:this.instance_4,p:{regX:155.8,scaleX:0.9989,scaleY:0.9989,rotation:-17.157,x:171.95,y:187.2,regY:18.6}},{t:this.ikNode_80,p:{scaleX:0.9987,scaleY:0.9987,rotation:-2.6647,x:469.9,y:291.35,regY:8.6}},{t:this.instance_3,p:{rotation:-38.4325,x:109.55,y:279.5,regX:55.1,scaleX:0.9988,scaleY:0.9988}},{t:this.instance_2,p:{rotation:-27.6915,x:133.5,y:238.35,scaleX:0.999,scaleY:0.999,regX:97.6,regY:59.6}},{t:this.ikNode_76,p:{regX:12.5,regY:5.6,scaleX:0.9987,scaleY:0.9987,rotation:46.5577,x:83.55,y:339.2}},{t:this.instance_1,p:{regX:38.4,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.4813,x:156.75,y:386.4}},{t:this.ikNode_83,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.363,x:220.2,y:396.75}},{t:this.instance,p:{regY:9.3,rotation:-0.3989,x:324.65,y:375.2,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_86,p:{regY:12.8,scaleX:0.9992,scaleY:0.9992,rotation:4.2264,x:394.85,y:391.6}}]},1).to({state:[{t:this.ikNode_67,p:{regX:11.8,rotation:1.2763,x:243.55,y:368.35}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9988,rotation:36.1652,x:409.2,y:273.45,scaleY:0.9988,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9985,scaleY:0.9985,rotation:-138.9412,x:361.7,y:260.8,regX:94.9,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-109.1374,x:304.25,y:220.65,regY:22.1,regX:155}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.4664,x:158.65,y:335.9,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-8.6277,x:319.5,y:341.85,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2826,x:245.3,y:327.4}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:4.9235,x:249.4,y:276.55,regY:128.7,regX:121.2}},{t:this.instance_6,p:{regX:37.6,scaleX:0.9991,scaleY:0.9991,rotation:-9.9522,x:230.9,y:156.25,startPosition:13,regY:150.3}},{t:this.ikNode_71,p:{scaleX:0.999,scaleY:0.999,rotation:96.4361,x:247.25,y:2.05,regX:5.7,regY:9.6}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:4.9235,x:202.95,y:169.1,regY:26.9,regX:65.9}},{t:this.instance_4,p:{regX:155.8,scaleX:0.999,scaleY:0.999,rotation:-16.7205,x:174.6,y:185.85,regY:18.6}},{t:this.ikNode_80,p:{scaleX:0.9988,scaleY:0.9988,rotation:-1.2738,x:469.95,y:297.1,regY:8.7}},{t:this.instance_3,p:{rotation:-40.9595,x:113.15,y:278.5,regX:55.1,scaleX:0.9989,scaleY:0.9989}},{t:this.instance_2,p:{rotation:-29.4586,x:135.8,y:236.7,scaleX:0.999,scaleY:0.999,regX:97.6,regY:59.6}},{t:this.ikNode_76,p:{regX:12.5,regY:5.5,scaleX:0.9987,scaleY:0.9987,rotation:36.9079,x:89.9,y:339.3}},{t:this.instance_1,p:{regX:38.4,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.4813,x:156.75,y:386.4}},{t:this.ikNode_83,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.363,x:220.2,y:396.75}},{t:this.instance,p:{regY:9.3,rotation:-0.3989,x:324.65,y:375.2,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_86,p:{regY:12.8,scaleX:0.9992,scaleY:0.9992,rotation:4.2264,x:394.85,y:391.6}}]},1).to({state:[{t:this.ikNode_67,p:{regX:11.8,rotation:1.2763,x:243.55,y:368.3}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9988,rotation:37.5553,x:409.65,y:277.65,scaleY:0.9988,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9985,scaleY:0.9985,rotation:-137.3062,x:362.6,y:263.75,regX:94.8,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-107.4177,x:306.25,y:221.85,regY:22.1,regX:154.9}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.4664,x:158.65,y:335.9,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-8.6277,x:319.5,y:341.85,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2826,x:245.25,y:327.4}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:6.016,x:250.45,y:276.65,regY:128.7,regX:121.3}},{t:this.instance_6,p:{regX:37.6,scaleX:0.9991,scaleY:0.9991,rotation:-9.1162,x:234.15,y:156,startPosition:14,regY:150.3}},{t:this.ikNode_71,p:{scaleX:0.999,scaleY:0.999,rotation:97.2708,x:252.95,y:2.05,regX:5.7,regY:9.5}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:6.016,x:206.05,y:168.3,regY:26.9,regX:66}},{t:this.instance_4,p:{regX:155.8,scaleX:0.999,scaleY:0.999,rotation:-16.2834,x:177.3,y:184.45,regY:18.6}},{t:this.ikNode_80,p:{scaleX:0.9987,scaleY:0.9987,rotation:0.112,x:469.8,y:302.65,regY:8.6}},{t:this.instance_3,p:{rotation:-43.4866,x:116.8,y:277.5,regX:55.1,scaleX:0.9989,scaleY:0.9989}},{t:this.instance_2,p:{rotation:-31.2249,x:138.1,y:235.05,scaleX:0.999,scaleY:0.999,regX:97.6,regY:59.6}},{t:this.ikNode_76,p:{regX:12.5,regY:5.6,scaleX:0.9987,scaleY:0.9987,rotation:27.2572,x:96.2,y:339.35}},{t:this.instance_1,p:{regX:38.4,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.4813,x:156.75,y:386.4}},{t:this.ikNode_83,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.363,x:220.25,y:396.75}},{t:this.instance,p:{regY:9.3,rotation:-0.3989,x:324.65,y:375.2,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_86,p:{regY:12.8,scaleX:0.9992,scaleY:0.9992,rotation:4.2264,x:394.8,y:391.6}}]},1).to({state:[{t:this.ikNode_67,p:{regX:11.8,rotation:1.2763,x:243.55,y:368.3}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9988,rotation:38.9465,x:409.95,y:281.8,scaleY:0.9988,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9985,scaleY:0.9985,rotation:-135.6705,x:363.25,y:266.6,regX:94.8,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9985,scaleY:0.9985,rotation:-105.6968,x:308.3,y:223.2,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.4664,x:158.65,y:335.9,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-8.6277,x:319.5,y:341.85,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2826,x:245.25,y:327.4}},{t:this.instance_7,p:{scaleX:0.9993,scaleY:0.9993,rotation:7.1087,x:251.6,y:276.75,regY:128.7,regX:121.4}},{t:this.instance_6,p:{regX:37.6,scaleX:0.9991,scaleY:0.9991,rotation:-8.2813,x:237.4,y:155.85,startPosition:15,regY:150.3}},{t:this.ikNode_71,p:{scaleX:0.999,scaleY:0.999,rotation:98.1061,x:258.35,y:2.15,regX:5.7,regY:9.6}},{t:this.instance_5,p:{scaleX:0.9993,scaleY:0.9993,rotation:7.1087,x:208.9,y:167.65,regY:27,regX:65.9}},{t:this.instance_4,p:{regX:155.8,scaleX:0.9989,scaleY:0.9989,rotation:-15.8453,x:180,y:183.15,regY:18.6}},{t:this.ikNode_80,p:{scaleX:0.9987,scaleY:0.9987,rotation:1.5032,x:469.45,y:308.3,regY:8.6}},{t:this.instance_3,p:{rotation:-46.0138,x:120.4,y:276.65,regX:55.1,scaleX:0.9988,scaleY:0.9988}},{t:this.instance_2,p:{rotation:-32.9922,x:140.45,y:233.5,scaleX:0.999,scaleY:0.999,regX:97.6,regY:59.6}},{t:this.ikNode_76,p:{regX:12.5,regY:5.6,scaleX:0.9987,scaleY:0.9987,rotation:17.6069,x:102.6,y:339.35}},{t:this.instance_1,p:{regX:38.4,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.4813,x:156.75,y:386.4}},{t:this.ikNode_83,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.3622,x:220.25,y:396.75}},{t:this.instance,p:{regY:9.3,rotation:-0.3989,x:324.6,y:375.2,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_86,p:{regY:12.8,scaleX:0.9992,scaleY:0.9992,rotation:4.2264,x:394.8,y:391.6}}]},1).to({state:[{t:this.ikNode_67,p:{regX:11.8,rotation:1.2755,x:243.55,y:368.3}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9988,rotation:40.3366,x:410.25,y:286.05,scaleY:0.9988,regX:12.3}},{t:this.instance_12,p:{scaleX:0.9985,scaleY:0.9985,rotation:-134.0335,x:363.9,y:269.45,regX:94.8,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-103.9768,x:310.25,y:224.3,regY:22.1,regX:154.9}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.4664,x:158.65,y:335.9,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-8.6277,x:319.5,y:341.9,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2826,x:245.25,y:327.4}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:8.2007,x:252.4,y:276.9,regY:128.7,regX:121.3}},{t:this.instance_6,p:{regX:37.6,scaleX:0.9991,scaleY:0.9991,rotation:-7.4439,x:240.65,y:155.85,startPosition:16,regY:150.3}},{t:this.ikNode_71,p:{scaleX:0.999,scaleY:0.999,rotation:98.9406,x:263.85,y:2.4,regX:5.7,regY:9.6}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:8.2007,x:212,y:166.85,regY:26.9,regX:65.9}},{t:this.instance_4,p:{regX:155.8,scaleX:0.999,scaleY:0.999,rotation:-15.4072,x:182.85,y:181.95,regY:18.6}},{t:this.ikNode_80,p:{scaleX:0.9987,scaleY:0.9987,rotation:2.8935,x:468.95,y:314.05,regY:8.7}},{t:this.instance_3,p:{rotation:-48.5406,x:124.1,y:275.7,regX:55.1,scaleX:0.9988,scaleY:0.9988}},{t:this.instance_2,p:{rotation:-34.7589,x:142.85,y:231.95,scaleX:0.999,scaleY:0.999,regX:97.6,regY:59.6}},{t:this.ikNode_76,p:{regX:12.5,regY:5.6,scaleX:0.9987,scaleY:0.9987,rotation:7.9579,x:109.1,y:339.15}},{t:this.instance_1,p:{regX:38.4,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.4813,x:156.75,y:386.45}},{t:this.ikNode_83,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.3622,x:220.25,y:396.75}},{t:this.instance,p:{regY:9.3,rotation:-0.3989,x:324.6,y:375.15,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_86,p:{regY:12.8,scaleX:0.9992,scaleY:0.9992,rotation:4.2264,x:394.8,y:391.6}}]},1).to({state:[{t:this.ikNode_67,p:{regX:11.8,rotation:1.2763,x:243.55,y:368.3}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9988,rotation:40.7736,x:409.3,y:284.55,scaleY:0.9988,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9985,scaleY:0.9985,rotation:-134.5419,x:362.85,y:268.5,regX:94.8,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-104.2214,x:309,y:223.55,regY:22.1,regX:154.9}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.4664,x:158.65,y:335.95,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-8.6277,x:319.5,y:341.9,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2826,x:245.25,y:327.4}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:7.5084,x:251.95,y:276.85,regY:128.7,regX:121.4}},{t:this.instance_6,p:{regX:37.6,scaleX:0.9991,scaleY:0.9991,rotation:-7.4368,x:238.6,y:155.85,startPosition:17,regY:150.3}},{t:this.ikNode_71,p:{scaleX:0.999,scaleY:0.999,rotation:98.9486,x:261.8,y:2.5,regX:5.7,regY:9.6}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:7.5084,x:210.2,y:167.35,regY:26.9,regX:66}},{t:this.instance_4,p:{regX:155.8,scaleX:0.9989,scaleY:0.9989,rotation:-15.7597,x:181.05,y:182.8,regY:18.6}},{t:this.ikNode_80,p:{scaleX:0.9988,scaleY:0.9988,rotation:3.3309,x:467.85,y:312.95,regY:8.6}},{t:this.instance_3,p:{rotation:-47.3823,x:122.7,y:276.7,regX:55.1,scaleX:0.9988,scaleY:0.9988}},{t:this.instance_2,p:{rotation:-34.7846,x:141.45,y:233,scaleX:0.999,scaleY:0.999,regX:97.6,regY:59.6}},{t:this.ikNode_76,p:{regX:12.4,regY:5.6,scaleX:0.9987,scaleY:0.9987,rotation:14.8149,x:106.25,y:339.7}},{t:this.instance_1,p:{regX:38.4,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.4813,x:156.75,y:386.45}},{t:this.ikNode_83,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.3622,x:220.25,y:396.75}},{t:this.instance,p:{regY:9.3,rotation:-0.3989,x:324.65,y:375.15,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_86,p:{regY:12.8,scaleX:0.9992,scaleY:0.9992,rotation:4.2264,x:394.8,y:391.6}}]},1).to({state:[{t:this.ikNode_67,p:{regX:11.8,rotation:1.2763,x:243.55,y:368.3}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9988,rotation:41.2086,x:408.3,y:283.2,scaleY:0.9988,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9985,scaleY:0.9985,rotation:-135.0489,x:361.75,y:267.35,regX:94.9,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-104.4665,x:307.75,y:222.9,regY:22.1,regX:154.8}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.4664,x:158.65,y:335.95,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-8.6277,x:319.5,y:341.9,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2826,x:245.25,y:327.4}},{t:this.instance_7,p:{scaleX:0.9993,scaleY:0.9993,rotation:6.8172,x:251.2,y:276.75,regY:128.7,regX:121.3}},{t:this.instance_6,p:{regX:37.6,scaleX:0.9991,scaleY:0.9991,rotation:-7.4298,x:236.5,y:155.95,startPosition:18,regY:150.3}},{t:this.ikNode_71,p:{scaleX:0.999,scaleY:0.999,rotation:98.9566,x:259.75,y:2.5,regX:5.7,regY:9.6}},{t:this.instance_5,p:{scaleX:0.9993,scaleY:0.9993,rotation:6.8172,x:208.1,y:167.75,regY:26.9,regX:65.9}},{t:this.instance_4,p:{regX:155.8,scaleX:0.9989,scaleY:0.9989,rotation:-16.112,x:179.3,y:183.55,regY:18.6}},{t:this.ikNode_80,p:{scaleX:0.9988,scaleY:0.9988,rotation:3.7668,x:466.65,y:311.9,regY:8.6}},{t:this.instance_3,p:{rotation:-46.2249,x:121.3,y:277.75,regX:55.1,scaleX:0.9988,scaleY:0.9988}},{t:this.instance_2,p:{rotation:-34.8093,x:139.95,y:234,scaleX:0.999,scaleY:0.999,regX:97.6,regY:59.6}},{t:this.ikNode_76,p:{regX:12.5,regY:5.6,scaleX:0.9987,scaleY:0.9987,rotation:21.6715,x:103.65,y:340.5}},{t:this.instance_1,p:{regX:38.4,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.4813,x:156.75,y:386.45}},{t:this.ikNode_83,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.3622,x:220.25,y:396.75}},{t:this.instance,p:{regY:9.3,rotation:-0.3989,x:324.65,y:375.15,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_86,p:{regY:12.8,scaleX:0.9992,scaleY:0.9992,rotation:4.2264,x:394.8,y:391.6}}]},1).to({state:[{t:this.ikNode_67,p:{regX:11.8,rotation:1.2763,x:243.55,y:368.3}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9988,rotation:41.6446,x:407.4,y:281.8,scaleY:0.9988,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9985,scaleY:0.9985,rotation:-135.5572,x:360.6,y:266.45,regX:94.9,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-104.7124,x:306.45,y:222.05,regY:22.1,regX:154.9}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.4664,x:158.65,y:335.95,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-8.6277,x:319.5,y:341.9,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2826,x:245.3,y:327.4}},{t:this.instance_7,p:{scaleX:0.9993,scaleY:0.9993,rotation:6.1233,x:250.65,y:276.8,regY:128.8,regX:121.4}},{t:this.instance_6,p:{regX:37.6,scaleX:0.9991,scaleY:0.9991,rotation:-7.4227,x:234.45,y:156.05,startPosition:19,regY:150.3}},{t:this.ikNode_71,p:{scaleX:0.999,scaleY:0.999,rotation:98.9628,x:257.7,y:2.7,regX:5.7,regY:9.6}},{t:this.instance_5,p:{scaleX:0.9993,scaleY:0.9993,rotation:6.1233,x:206.4,y:168.3,regY:26.9,regX:66}},{t:this.instance_4,p:{regX:155.8,scaleX:0.999,scaleY:0.999,rotation:-16.4638,x:177.55,y:184.35,regY:18.6}},{t:this.ikNode_80,p:{scaleX:0.9988,scaleY:0.9988,rotation:4.2029,x:465.45,y:311,regY:8.6}},{t:this.instance_3,p:{rotation:-45.065,x:119.9,y:278.8,regX:55.1,scaleX:0.9988,scaleY:0.9988}},{t:this.instance_2,p:{rotation:-34.8351,x:138.55,y:235.05,scaleX:0.999,scaleY:0.999,regX:97.6,regY:59.6}},{t:this.ikNode_76,p:{regX:12.5,regY:5.6,scaleX:0.9987,scaleY:0.9987,rotation:28.5289,x:101.05,y:341.1}},{t:this.instance_1,p:{regX:38.4,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.4813,x:156.75,y:386.45}},{t:this.ikNode_83,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.363,x:220.25,y:396.75}},{t:this.instance,p:{regY:9.3,rotation:-0.3989,x:324.65,y:375.15,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_86,p:{regY:12.8,scaleX:0.9992,scaleY:0.9992,rotation:4.2264,x:394.8,y:391.6}}]},1).to({state:[{t:this.ikNode_67,p:{regX:11.8,rotation:1.2763,x:243.55,y:368.35}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9988,rotation:42.0816,x:406.45,y:280.4,scaleY:0.9988,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9985,scaleY:0.9985,rotation:-136.0656,x:359.55,y:265.45,regX:94.9,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-104.956,x:305.2,y:221.3,regY:22.1,regX:154.9}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.4664,x:158.65,y:335.95,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-8.6277,x:319.5,y:341.9,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2826,x:245.3,y:327.45}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:5.433,x:249.95,y:276.75,regY:128.8,regX:121.3}},{t:this.instance_6,p:{regX:37.6,scaleX:0.9991,scaleY:0.9991,rotation:-7.4165,x:232.35,y:156.2,startPosition:20,regY:150.3}},{t:this.ikNode_71,p:{scaleX:0.999,scaleY:0.999,rotation:98.9709,x:255.65,y:2.85,regX:5.7,regY:9.6}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:5.433,x:204.35,y:168.75,regY:26.9,regX:65.9}},{t:this.instance_4,p:{regX:155.8,scaleX:0.9989,scaleY:0.9989,rotation:-16.8148,x:175.9,y:185.25,regY:18.6}},{t:this.ikNode_80,p:{scaleX:0.9987,scaleY:0.9987,rotation:4.6393,x:464.35,y:310.05,regY:8.6}},{t:this.instance_3,p:{rotation:-43.9069,x:118.55,y:279.9,regX:55.1,scaleX:0.9988,scaleY:0.9988}},{t:this.instance_2,p:{rotation:-34.8596,x:137.25,y:236.05,scaleX:0.999,scaleY:0.999,regX:97.7,regY:59.6}},{t:this.ikNode_76,p:{regX:12.5,regY:5.6,scaleX:0.9987,scaleY:0.9987,rotation:35.3855,x:98.4,y:341.9}},{t:this.instance_1,p:{regX:38.4,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.4813,x:156.75,y:386.45}},{t:this.ikNode_83,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.363,x:220.25,y:396.75}},{t:this.instance,p:{regY:9.3,rotation:-0.3989,x:324.65,y:375.15,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_86,p:{regY:12.8,scaleX:0.9992,scaleY:0.9992,rotation:4.2264,x:394.8,y:391.6}}]},1).to({state:[{t:this.ikNode_67,p:{regX:11.8,rotation:1.2763,x:243.55,y:368.35}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9988,rotation:42.5191,x:405.5,y:279.05,scaleY:0.9988,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9985,scaleY:0.9985,rotation:-136.5739,x:358.45,y:264.65,regX:94.8,regY:63.4}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-105.2017,x:303.95,y:220.6,regY:22.1,regX:154.9}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.4664,x:158.65,y:335.95,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-8.6277,x:319.5,y:341.9,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2826,x:245.3,y:327.45}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:4.74,x:249.25,y:276.55,regY:128.7,regX:121.2}},{t:this.instance_6,p:{regX:37.6,scaleX:0.9991,scaleY:0.9991,rotation:-7.4095,x:230.25,y:156.4,startPosition:21,regY:150.3}},{t:this.ikNode_71,p:{scaleX:0.999,scaleY:0.999,rotation:98.9779,x:253.6,y:2.95,regX:5.7,regY:9.6}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:4.74,x:202.45,y:169.2,regY:26.9,regX:65.9}},{t:this.instance_4,p:{regX:155.8,scaleX:0.9989,scaleY:0.9989,rotation:-17.167,x:174.2,y:186.05,regY:18.6}},{t:this.ikNode_80,p:{scaleX:0.9987,scaleY:0.9987,rotation:5.0751,x:463.2,y:309.15,regY:8.6}},{t:this.instance_3,p:{rotation:-42.7472,x:117.15,y:280.95,regX:55.1,scaleX:0.9988,scaleY:0.9988}},{t:this.instance_2,p:{rotation:-34.8851,x:135.75,y:237.25,scaleX:0.999,scaleY:0.999,regX:97.6,regY:59.6}},{t:this.ikNode_76,p:{regX:12.5,regY:5.6,scaleX:0.9987,scaleY:0.9987,rotation:42.2431,x:95.75,y:342.55}},{t:this.instance_1,p:{regX:38.4,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.4813,x:156.75,y:386.45}},{t:this.ikNode_83,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.363,x:220.25,y:396.8}},{t:this.instance,p:{regY:9.3,rotation:-0.3989,x:324.65,y:375.2,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_86,p:{regY:12.8,scaleX:0.9992,scaleY:0.9992,rotation:4.2264,x:394.8,y:391.6}}]},1).to({state:[{t:this.ikNode_67,p:{regX:11.8,rotation:1.2763,x:243.55,y:368.35}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9988,rotation:42.9533,x:404.5,y:277.7,scaleY:0.9988,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9985,scaleY:0.9985,rotation:-137.0813,x:357.5,y:263.6,regX:94.8,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-105.4468,x:302.6,y:219.75,regY:22.1,regX:155}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.4673,x:158.65,y:335.95,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-8.6277,x:319.5,y:341.9,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2826,x:245.3,y:327.45}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:4.0495,x:248.55,y:276.55,regY:128.7,regX:121.2}},{t:this.instance_6,p:{regX:37.6,scaleX:0.9991,scaleY:0.9991,rotation:-7.4023,x:228.2,y:156.55,startPosition:22,regY:150.3}},{t:this.ikNode_71,p:{scaleX:0.999,scaleY:0.999,rotation:98.985,x:251.55,y:3.2,regX:5.7,regY:9.6}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:4.0495,x:200.55,y:169.7,regY:26.9,regX:65.9}},{t:this.instance_4,p:{regX:155.8,scaleX:0.999,scaleY:0.999,rotation:-17.5188,x:172.5,y:186.85,regY:18.6}},{t:this.ikNode_80,p:{scaleX:0.9987,scaleY:0.9987,rotation:5.512,x:461.9,y:308.2,regY:8.6}},{t:this.instance_3,p:{rotation:-41.5883,x:115.8,y:282.05,regX:55.1,scaleX:0.9988,scaleY:0.9988}},{t:this.instance_2,p:{rotation:-34.9099,x:134.2,y:238.4,scaleX:0.999,scaleY:0.999,regX:97.5,regY:59.6}},{t:this.ikNode_76,p:{regX:12.5,regY:5.6,scaleX:0.9987,scaleY:0.9987,rotation:49.0996,x:93.1,y:343.25}},{t:this.instance_1,p:{regX:38.4,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.4813,x:156.75,y:386.45}},{t:this.ikNode_83,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.363,x:220.25,y:396.8}},{t:this.instance,p:{regY:9.3,rotation:-0.3989,x:324.65,y:375.2,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_86,p:{regY:12.8,scaleX:0.9992,scaleY:0.9992,rotation:4.2264,x:394.8,y:391.6}}]},1).to({state:[{t:this.ikNode_67,p:{regX:11.8,rotation:1.2772,x:243.55,y:368.35}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9988,rotation:43.3899,x:403.5,y:276.35,scaleY:0.9988,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9985,scaleY:0.9985,rotation:-137.59,x:356.3,y:262.7,regX:94.8,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9985,scaleY:0.9985,rotation:-105.6915,x:301.35,y:219.15,regY:22.1,regX:154.9}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.4673,x:158.65,y:335.95,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-8.6277,x:319.5,y:341.9,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2826,x:245.3,y:327.45}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:3.3561,x:248,y:276.5,regY:128.7,regX:121.2}},{t:this.instance_6,p:{regX:37.6,scaleX:0.9991,scaleY:0.9991,rotation:-7.3954,x:226.25,y:156.75,startPosition:23,regY:150.3}},{t:this.ikNode_71,p:{scaleX:0.999,scaleY:0.999,rotation:98.993,x:249.55,y:3.4,regX:5.6,regY:9.6}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:3.3561,x:198.7,y:170.35,regY:26.9,regX:65.9}},{t:this.instance_4,p:{regX:155.8,scaleX:0.999,scaleY:0.999,rotation:-17.8698,x:170.85,y:187.9,regY:18.7}},{t:this.ikNode_80,p:{scaleX:0.9988,scaleY:0.9988,rotation:5.9474,x:460.65,y:307.3,regY:8.6}},{t:this.instance_3,p:{rotation:-40.4294,x:114.5,y:283.2,regX:55.1,scaleX:0.9988,scaleY:0.9988}},{t:this.instance_2,p:{rotation:-34.9356,x:133.05,y:239.35,scaleX:0.999,scaleY:0.999,regX:97.7,regY:59.6}},{t:this.ikNode_76,p:{regX:12.5,regY:5.7,scaleX:0.9987,scaleY:0.9987,rotation:55.9571,x:90.5,y:344}},{t:this.instance_1,p:{regX:38.4,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.4813,x:156.75,y:386.45}},{t:this.ikNode_83,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.363,x:220.25,y:396.8}},{t:this.instance,p:{regY:9.3,rotation:-0.3998,x:324.65,y:375.25,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_86,p:{regY:12.8,scaleX:0.9992,scaleY:0.9992,rotation:4.2264,x:394.8,y:391.6}}]},1).to({state:[{t:this.ikNode_67,p:{regX:11.8,rotation:1.2772,x:243.55,y:368.35}},{t:this.instance_13,p:{regY:38.8,scaleX:0.9988,rotation:43.8264,x:402.55,y:274.95,scaleY:0.9988,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9985,scaleY:0.9985,rotation:-138.0977,x:355.25,y:261.8,regX:94.8,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-105.9371,x:300.05,y:218.5,regY:22.1,regX:154.9}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.4673,x:158.65,y:335.95,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-8.6277,x:319.5,y:341.9,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2826,x:245.3,y:327.45}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:2.6648,x:247.5,y:276.55,regY:128.8,regX:121.3}},{t:this.instance_6,p:{regX:37.6,scaleX:0.9991,scaleY:0.9991,rotation:-7.3883,x:224.15,y:157,startPosition:24,regY:150.3}},{t:this.ikNode_71,p:{scaleX:0.999,scaleY:0.999,rotation:99.0001,x:247.5,y:3.6,regX:5.6,regY:9.6}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:2.6648,x:196.75,y:170.85,regY:26.9,regX:65.9}},{t:this.instance_4,p:{regX:155.8,scaleX:0.9989,scaleY:0.9989,rotation:-18.2216,x:169.2,y:188.7,regY:18.6}},{t:this.ikNode_80,p:{scaleX:0.9987,scaleY:0.9987,rotation:6.3843,x:459.5,y:306.4,regY:8.6}},{t:this.instance_3,p:{rotation:-39.2711,x:113.15,y:284.35,regX:55.1,scaleX:0.9988,scaleY:0.9988}},{t:this.instance_2,p:{rotation:-34.9601,x:131.5,y:240.6,scaleX:0.999,scaleY:0.999,regX:97.5,regY:59.6}},{t:this.ikNode_76,p:{regX:12.5,regY:5.5,scaleX:0.9987,scaleY:0.9987,rotation:62.8132,x:88.05,y:344.5}},{t:this.instance_1,p:{regX:38.4,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.4813,x:156.75,y:386.45}},{t:this.ikNode_83,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.3647,x:220.25,y:396.8}},{t:this.instance,p:{regY:9.3,rotation:-0.3998,x:324.65,y:375.25,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_86,p:{regY:12.8,scaleX:0.9992,scaleY:0.9992,rotation:4.2264,x:394.8,y:391.6}}]},1).to({state:[{t:this.ikNode_67,p:{regX:11.8,rotation:1.2772,x:243.55,y:368.35}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9988,rotation:44.2616,x:401.55,y:273.7,scaleY:0.9988,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9985,scaleY:0.9985,rotation:-138.6044,x:354.15,y:260.9,regX:94.8,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-106.1812,x:298.75,y:217.85,regY:22.1,regX:154.9}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.4673,x:158.65,y:335.95,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-8.6277,x:319.5,y:341.9,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2826,x:245.3,y:327.45}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.9731,x:246.9,y:276.4,regY:128.7,regX:121.3}},{t:this.instance_6,p:{regX:37.6,scaleX:0.9991,scaleY:0.9991,rotation:-7.3813,x:222.1,y:157.25,startPosition:25,regY:150.3}},{t:this.ikNode_71,p:{scaleX:0.999,scaleY:0.999,rotation:99.0071,x:245.45,y:3.9,regX:5.6,regY:9.6}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.9731,x:194.75,y:171.45,regY:26.9,regX:65.8}},{t:this.instance_4,p:{regX:155.8,scaleX:0.999,scaleY:0.999,rotation:-18.5731,x:167.45,y:189.7,regY:18.6}},{t:this.ikNode_80,p:{scaleX:0.9987,scaleY:0.9987,rotation:6.8205,x:458.25,y:305.55,regY:8.6}},{t:this.instance_3,p:{rotation:-38.1122,x:111.8,y:285.5,regX:55.1,scaleX:0.9988,scaleY:0.9988}},{t:this.instance_2,p:{rotation:-34.9856,x:130.3,y:241.7,scaleX:0.999,scaleY:0.999,regX:97.6,regY:59.6}},{t:this.ikNode_76,p:{regX:12.5,regY:5.6,scaleX:0.9987,scaleY:0.9987,rotation:69.6709,x:85.45,y:345.25}},{t:this.instance_1,p:{regX:38.4,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.4813,x:156.75,y:386.45}},{t:this.ikNode_83,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.3647,x:220.25,y:396.8}},{t:this.instance,p:{regY:9.3,rotation:-0.3998,x:324.65,y:375.25,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_86,p:{regY:12.8,scaleX:0.9992,scaleY:0.9992,rotation:4.2264,x:394.8,y:391.6}}]},1).to({state:[{t:this.ikNode_67,p:{regX:11.8,rotation:1.2772,x:243.55,y:368.35}},{t:this.instance_13,p:{regY:38.9,scaleX:0.9988,rotation:44.6979,x:400.35,y:272.45,scaleY:0.9988,regX:12.2}},{t:this.instance_12,p:{scaleX:0.9985,scaleY:0.9985,rotation:-139.1126,x:353,y:259.95,regX:94.8,regY:63.5}},{t:this.instance_11,p:{scaleX:0.9986,scaleY:0.9986,rotation:-106.4267,x:297.4,y:217.25,regY:22.1,regX:154.9}},{t:this.instance_10,p:{regX:28.6,scaleX:0.9992,scaleY:0.9992,rotation:-0.4673,x:158.65,y:335.95,regY:17.2}},{t:this.instance_9,p:{regX:26.4,scaleX:0.9991,scaleY:0.9991,rotation:-8.6277,x:319.5,y:341.9,regY:17.8}},{t:this.instance_8,p:{regX:127.2,regY:82.9,scaleX:0.9994,scaleY:0.9994,rotation:1.2826,x:245.3,y:327.45}},{t:this.instance_7,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2809,x:246.3,y:276.35,regY:128.7,regX:121.3}},{t:this.instance_6,p:{regX:37.6,scaleX:0.9991,scaleY:0.9991,rotation:-7.3751,x:220.05,y:157.6,startPosition:26,regY:150.3}},{t:this.ikNode_71,p:{scaleX:0.999,scaleY:0.999,rotation:99.0142,x:243.45,y:4.1,regX:5.6,regY:9.6}},{t:this.instance_5,p:{scaleX:0.9994,scaleY:0.9994,rotation:1.2809,x:193.05,y:172.05,regY:26.9,regX:65.9}},{t:this.instance_4,p:{regX:155.8,scaleX:0.9989,scaleY:0.9989,rotation:-18.9243,x:165.85,y:190.55,regY:18.6}},{t:this.ikNode_80,p:{scaleX:0.9987,scaleY:0.9987,rotation:7.2562,x:456.9,y:304.65,regY:8.6}},{t:this.instance_3,p:{rotation:-36.953,x:110.5,y:286.7,regX:55.1,scaleX:0.9988,scaleY:0.9988}},{t:this.instance_2,p:{rotation:-35.0121,x:129,y:242.8,scaleX:0.999,scaleY:0.999,regX:97.6,regY:59.6}},{t:this.ikNode_76,p:{regX:12.5,regY:5.6,scaleX:0.9987,scaleY:0.9987,rotation:76.5277,x:82.85,y:345.9}},{t:this.instance_1,p:{regX:38.4,regY:10.5,scaleX:0.9992,scaleY:0.9992,rotation:-5.4813,x:156.8,y:386.5}},{t:this.ikNode_83,p:{scaleX:0.9989,scaleY:0.9989,rotation:34.3647,x:220.3,y:396.85}},{t:this.instance,p:{regY:9.3,rotation:-0.3998,x:324.65,y:375.25,scaleX:0.9994,scaleY:0.9994,regX:19.8}},{t:this.ikNode_86,p:{regY:12.8,scaleX:0.9992,scaleY:0.9992,rotation:4.2264,x:394.8,y:391.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Rhino_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{Stationary:24});

	// timeline functions:
	this.frame_0 = function() {
		this.ikNode_27 = this.Armature_7.ikNode_27;
		this.ikNode_31 = this.Armature_7.ikNode_31;
		this.ikNode_37 = this.Armature_7.ikNode_37;
		this.ikNode_40 = this.Armature_7.ikNode_40;
		this.ikNode_44 = this.Armature_7.ikNode_44;
		this.ikNode_46 = this.Armature_7.ikNode_46;
	}
	this.frame_1 = function() {
		this.ikNode_27 = undefined;this.ikNode_31 = undefined;this.ikNode_37 = undefined;this.ikNode_40 = undefined;this.ikNode_44 = undefined;this.ikNode_46 = undefined;this.ikNode_27 = this.Armature_7.ikNode_27;
		this.ikNode_31 = this.Armature_7.ikNode_31;
		this.ikNode_37 = this.Armature_7.ikNode_37;
		this.ikNode_40 = this.Armature_7.ikNode_40;
		this.ikNode_44 = this.Armature_7.ikNode_44;
		this.ikNode_46 = this.Armature_7.ikNode_46;
	}
	this.frame_2 = function() {
		this.ikNode_27 = undefined;this.ikNode_31 = undefined;this.ikNode_37 = undefined;this.ikNode_40 = undefined;this.ikNode_44 = undefined;this.ikNode_46 = undefined;this.ikNode_27 = this.Armature_7.ikNode_27;
		this.ikNode_31 = this.Armature_7.ikNode_31;
		this.ikNode_37 = this.Armature_7.ikNode_37;
		this.ikNode_40 = this.Armature_7.ikNode_40;
		this.ikNode_44 = this.Armature_7.ikNode_44;
		this.ikNode_46 = this.Armature_7.ikNode_46;
	}
	this.frame_3 = function() {
		this.ikNode_27 = undefined;this.ikNode_31 = undefined;this.ikNode_37 = undefined;this.ikNode_40 = undefined;this.ikNode_44 = undefined;this.ikNode_46 = undefined;this.ikNode_27 = this.Armature_7.ikNode_27;
		this.ikNode_31 = this.Armature_7.ikNode_31;
		this.ikNode_37 = this.Armature_7.ikNode_37;
		this.ikNode_40 = this.Armature_7.ikNode_40;
		this.ikNode_44 = this.Armature_7.ikNode_44;
		this.ikNode_46 = this.Armature_7.ikNode_46;
	}
	this.frame_4 = function() {
		this.ikNode_27 = undefined;this.ikNode_31 = undefined;this.ikNode_37 = undefined;this.ikNode_40 = undefined;this.ikNode_44 = undefined;this.ikNode_46 = undefined;this.ikNode_27 = this.Armature_7.ikNode_27;
		this.ikNode_31 = this.Armature_7.ikNode_31;
		this.ikNode_37 = this.Armature_7.ikNode_37;
		this.ikNode_40 = this.Armature_7.ikNode_40;
		this.ikNode_44 = this.Armature_7.ikNode_44;
		this.ikNode_46 = this.Armature_7.ikNode_46;
	}
	this.frame_5 = function() {
		this.ikNode_27 = undefined;this.ikNode_31 = undefined;this.ikNode_37 = undefined;this.ikNode_40 = undefined;this.ikNode_44 = undefined;this.ikNode_46 = undefined;this.ikNode_27 = this.Armature_7.ikNode_27;
		this.ikNode_31 = this.Armature_7.ikNode_31;
		this.ikNode_37 = this.Armature_7.ikNode_37;
		this.ikNode_40 = this.Armature_7.ikNode_40;
		this.ikNode_44 = this.Armature_7.ikNode_44;
		this.ikNode_46 = this.Armature_7.ikNode_46;
	}
	this.frame_6 = function() {
		this.ikNode_27 = undefined;this.ikNode_31 = undefined;this.ikNode_37 = undefined;this.ikNode_40 = undefined;this.ikNode_44 = undefined;this.ikNode_46 = undefined;this.ikNode_27 = this.Armature_7.ikNode_27;
		this.ikNode_31 = this.Armature_7.ikNode_31;
		this.ikNode_37 = this.Armature_7.ikNode_37;
		this.ikNode_40 = this.Armature_7.ikNode_40;
		this.ikNode_44 = this.Armature_7.ikNode_44;
		this.ikNode_46 = this.Armature_7.ikNode_46;
	}
	this.frame_7 = function() {
		this.ikNode_27 = undefined;this.ikNode_31 = undefined;this.ikNode_37 = undefined;this.ikNode_40 = undefined;this.ikNode_44 = undefined;this.ikNode_46 = undefined;this.ikNode_27 = this.Armature_7.ikNode_27;
		this.ikNode_31 = this.Armature_7.ikNode_31;
		this.ikNode_37 = this.Armature_7.ikNode_37;
		this.ikNode_40 = this.Armature_7.ikNode_40;
		this.ikNode_44 = this.Armature_7.ikNode_44;
		this.ikNode_46 = this.Armature_7.ikNode_46;
	}
	this.frame_8 = function() {
		this.ikNode_27 = undefined;this.ikNode_31 = undefined;this.ikNode_37 = undefined;this.ikNode_40 = undefined;this.ikNode_44 = undefined;this.ikNode_46 = undefined;this.ikNode_27 = this.Armature_7.ikNode_27;
		this.ikNode_31 = this.Armature_7.ikNode_31;
		this.ikNode_37 = this.Armature_7.ikNode_37;
		this.ikNode_40 = this.Armature_7.ikNode_40;
		this.ikNode_44 = this.Armature_7.ikNode_44;
		this.ikNode_46 = this.Armature_7.ikNode_46;
	}
	this.frame_9 = function() {
		this.ikNode_27 = undefined;this.ikNode_31 = undefined;this.ikNode_37 = undefined;this.ikNode_40 = undefined;this.ikNode_44 = undefined;this.ikNode_46 = undefined;this.ikNode_27 = this.Armature_7.ikNode_27;
		this.ikNode_31 = this.Armature_7.ikNode_31;
		this.ikNode_37 = this.Armature_7.ikNode_37;
		this.ikNode_40 = this.Armature_7.ikNode_40;
		this.ikNode_44 = this.Armature_7.ikNode_44;
		this.ikNode_46 = this.Armature_7.ikNode_46;
	}
	this.frame_10 = function() {
		this.ikNode_27 = undefined;this.ikNode_31 = undefined;this.ikNode_37 = undefined;this.ikNode_40 = undefined;this.ikNode_44 = undefined;this.ikNode_46 = undefined;this.ikNode_27 = this.Armature_7.ikNode_27;
		this.ikNode_31 = this.Armature_7.ikNode_31;
		this.ikNode_37 = this.Armature_7.ikNode_37;
		this.ikNode_40 = this.Armature_7.ikNode_40;
		this.ikNode_44 = this.Armature_7.ikNode_44;
		this.ikNode_46 = this.Armature_7.ikNode_46;
	}
	this.frame_11 = function() {
		this.ikNode_27 = undefined;this.ikNode_31 = undefined;this.ikNode_37 = undefined;this.ikNode_40 = undefined;this.ikNode_44 = undefined;this.ikNode_46 = undefined;this.ikNode_27 = this.Armature_7.ikNode_27;
		this.ikNode_31 = this.Armature_7.ikNode_31;
		this.ikNode_37 = this.Armature_7.ikNode_37;
		this.ikNode_40 = this.Armature_7.ikNode_40;
		this.ikNode_44 = this.Armature_7.ikNode_44;
		this.ikNode_46 = this.Armature_7.ikNode_46;
	}
	this.frame_12 = function() {
		this.ikNode_27 = undefined;this.ikNode_31 = undefined;this.ikNode_37 = undefined;this.ikNode_40 = undefined;this.ikNode_44 = undefined;this.ikNode_46 = undefined;this.ikNode_27 = this.Armature_7.ikNode_27;
		this.ikNode_31 = this.Armature_7.ikNode_31;
		this.ikNode_37 = this.Armature_7.ikNode_37;
		this.ikNode_40 = this.Armature_7.ikNode_40;
		this.ikNode_44 = this.Armature_7.ikNode_44;
		this.ikNode_46 = this.Armature_7.ikNode_46;
	}
	this.frame_13 = function() {
		this.ikNode_27 = undefined;this.ikNode_31 = undefined;this.ikNode_37 = undefined;this.ikNode_40 = undefined;this.ikNode_44 = undefined;this.ikNode_46 = undefined;this.ikNode_27 = this.Armature_7.ikNode_27;
		this.ikNode_31 = this.Armature_7.ikNode_31;
		this.ikNode_37 = this.Armature_7.ikNode_37;
		this.ikNode_40 = this.Armature_7.ikNode_40;
		this.ikNode_44 = this.Armature_7.ikNode_44;
		this.ikNode_46 = this.Armature_7.ikNode_46;
	}
	this.frame_14 = function() {
		this.ikNode_27 = undefined;this.ikNode_31 = undefined;this.ikNode_37 = undefined;this.ikNode_40 = undefined;this.ikNode_44 = undefined;this.ikNode_46 = undefined;this.ikNode_27 = this.Armature_7.ikNode_27;
		this.ikNode_31 = this.Armature_7.ikNode_31;
		this.ikNode_37 = this.Armature_7.ikNode_37;
		this.ikNode_40 = this.Armature_7.ikNode_40;
		this.ikNode_44 = this.Armature_7.ikNode_44;
		this.ikNode_46 = this.Armature_7.ikNode_46;
	}
	this.frame_15 = function() {
		this.ikNode_27 = undefined;this.ikNode_31 = undefined;this.ikNode_37 = undefined;this.ikNode_40 = undefined;this.ikNode_44 = undefined;this.ikNode_46 = undefined;this.ikNode_27 = this.Armature_7.ikNode_27;
		this.ikNode_31 = this.Armature_7.ikNode_31;
		this.ikNode_37 = this.Armature_7.ikNode_37;
		this.ikNode_40 = this.Armature_7.ikNode_40;
		this.ikNode_44 = this.Armature_7.ikNode_44;
		this.ikNode_46 = this.Armature_7.ikNode_46;
	}
	this.frame_16 = function() {
		this.ikNode_27 = undefined;this.ikNode_31 = undefined;this.ikNode_37 = undefined;this.ikNode_40 = undefined;this.ikNode_44 = undefined;this.ikNode_46 = undefined;this.ikNode_27 = this.Armature_7.ikNode_27;
		this.ikNode_31 = this.Armature_7.ikNode_31;
		this.ikNode_37 = this.Armature_7.ikNode_37;
		this.ikNode_40 = this.Armature_7.ikNode_40;
		this.ikNode_44 = this.Armature_7.ikNode_44;
		this.ikNode_46 = this.Armature_7.ikNode_46;
	}
	this.frame_17 = function() {
		this.ikNode_27 = undefined;this.ikNode_31 = undefined;this.ikNode_37 = undefined;this.ikNode_40 = undefined;this.ikNode_44 = undefined;this.ikNode_46 = undefined;this.ikNode_27 = this.Armature_7.ikNode_27;
		this.ikNode_31 = this.Armature_7.ikNode_31;
		this.ikNode_37 = this.Armature_7.ikNode_37;
		this.ikNode_40 = this.Armature_7.ikNode_40;
		this.ikNode_44 = this.Armature_7.ikNode_44;
		this.ikNode_46 = this.Armature_7.ikNode_46;
	}
	this.frame_18 = function() {
		this.ikNode_27 = undefined;this.ikNode_31 = undefined;this.ikNode_37 = undefined;this.ikNode_40 = undefined;this.ikNode_44 = undefined;this.ikNode_46 = undefined;this.ikNode_27 = this.Armature_7.ikNode_27;
		this.ikNode_31 = this.Armature_7.ikNode_31;
		this.ikNode_37 = this.Armature_7.ikNode_37;
		this.ikNode_40 = this.Armature_7.ikNode_40;
		this.ikNode_44 = this.Armature_7.ikNode_44;
		this.ikNode_46 = this.Armature_7.ikNode_46;
	}
	this.frame_19 = function() {
		this.ikNode_27 = undefined;this.ikNode_31 = undefined;this.ikNode_37 = undefined;this.ikNode_40 = undefined;this.ikNode_44 = undefined;this.ikNode_46 = undefined;this.ikNode_27 = this.Armature_7.ikNode_27;
		this.ikNode_31 = this.Armature_7.ikNode_31;
		this.ikNode_37 = this.Armature_7.ikNode_37;
		this.ikNode_40 = this.Armature_7.ikNode_40;
		this.ikNode_44 = this.Armature_7.ikNode_44;
		this.ikNode_46 = this.Armature_7.ikNode_46;
	}
	this.frame_20 = function() {
		this.ikNode_27 = undefined;this.ikNode_31 = undefined;this.ikNode_37 = undefined;this.ikNode_40 = undefined;this.ikNode_44 = undefined;this.ikNode_46 = undefined;this.ikNode_27 = this.Armature_7.ikNode_27;
		this.ikNode_31 = this.Armature_7.ikNode_31;
		this.ikNode_37 = this.Armature_7.ikNode_37;
		this.ikNode_40 = this.Armature_7.ikNode_40;
		this.ikNode_44 = this.Armature_7.ikNode_44;
		this.ikNode_46 = this.Armature_7.ikNode_46;
	}
	this.frame_21 = function() {
		this.ikNode_27 = undefined;this.ikNode_31 = undefined;this.ikNode_37 = undefined;this.ikNode_40 = undefined;this.ikNode_44 = undefined;this.ikNode_46 = undefined;this.ikNode_27 = this.Armature_7.ikNode_27;
		this.ikNode_31 = this.Armature_7.ikNode_31;
		this.ikNode_37 = this.Armature_7.ikNode_37;
		this.ikNode_40 = this.Armature_7.ikNode_40;
		this.ikNode_44 = this.Armature_7.ikNode_44;
		this.ikNode_46 = this.Armature_7.ikNode_46;
	}
	this.frame_22 = function() {
		this.ikNode_27 = undefined;this.ikNode_31 = undefined;this.ikNode_37 = undefined;this.ikNode_40 = undefined;this.ikNode_44 = undefined;this.ikNode_46 = undefined;this.ikNode_27 = this.Armature_7.ikNode_27;
		this.ikNode_31 = this.Armature_7.ikNode_31;
		this.ikNode_37 = this.Armature_7.ikNode_37;
		this.ikNode_40 = this.Armature_7.ikNode_40;
		this.ikNode_44 = this.Armature_7.ikNode_44;
		this.ikNode_46 = this.Armature_7.ikNode_46;
	}
	this.frame_23 = function() {
		this.ikNode_27 = undefined;this.ikNode_31 = undefined;this.ikNode_37 = undefined;this.ikNode_40 = undefined;this.ikNode_44 = undefined;this.ikNode_46 = undefined;this.ikNode_27 = this.Armature_7.ikNode_27;
		this.ikNode_31 = this.Armature_7.ikNode_31;
		this.ikNode_37 = this.Armature_7.ikNode_37;
		this.ikNode_40 = this.Armature_7.ikNode_40;
		this.ikNode_44 = this.Armature_7.ikNode_44;
		this.ikNode_46 = this.Armature_7.ikNode_46;
		this.gotoAndPlay(0);
	}
	this.frame_24 = function() {
		this.ikNode_27 = undefined;this.ikNode_31 = undefined;this.ikNode_37 = undefined;this.ikNode_40 = undefined;this.ikNode_44 = undefined;this.ikNode_46 = undefined;this.ikNode_67 = this.Armature_7.ikNode_67;
		this.ikNode_71 = this.Armature_7.ikNode_71;
		this.ikNode_80 = this.Armature_7.ikNode_80;
		this.ikNode_76 = this.Armature_7.ikNode_76;
		this.ikNode_83 = this.Armature_7.ikNode_83;
		this.ikNode_86 = this.Armature_7.ikNode_86;
	}
	this.frame_25 = function() {
		this.ikNode_67 = undefined;this.ikNode_71 = undefined;this.ikNode_80 = undefined;this.ikNode_76 = undefined;this.ikNode_83 = undefined;this.ikNode_86 = undefined;this.ikNode_67 = this.Armature_7.ikNode_67;
		this.ikNode_71 = this.Armature_7.ikNode_71;
		this.ikNode_80 = this.Armature_7.ikNode_80;
		this.ikNode_76 = this.Armature_7.ikNode_76;
		this.ikNode_83 = this.Armature_7.ikNode_83;
		this.ikNode_86 = this.Armature_7.ikNode_86;
	}
	this.frame_26 = function() {
		this.ikNode_67 = undefined;this.ikNode_71 = undefined;this.ikNode_80 = undefined;this.ikNode_76 = undefined;this.ikNode_83 = undefined;this.ikNode_86 = undefined;this.ikNode_67 = this.Armature_7.ikNode_67;
		this.ikNode_71 = this.Armature_7.ikNode_71;
		this.ikNode_80 = this.Armature_7.ikNode_80;
		this.ikNode_76 = this.Armature_7.ikNode_76;
		this.ikNode_83 = this.Armature_7.ikNode_83;
		this.ikNode_86 = this.Armature_7.ikNode_86;
	}
	this.frame_27 = function() {
		this.ikNode_67 = undefined;this.ikNode_71 = undefined;this.ikNode_80 = undefined;this.ikNode_76 = undefined;this.ikNode_83 = undefined;this.ikNode_86 = undefined;this.ikNode_67 = this.Armature_7.ikNode_67;
		this.ikNode_71 = this.Armature_7.ikNode_71;
		this.ikNode_80 = this.Armature_7.ikNode_80;
		this.ikNode_76 = this.Armature_7.ikNode_76;
		this.ikNode_83 = this.Armature_7.ikNode_83;
		this.ikNode_86 = this.Armature_7.ikNode_86;
	}
	this.frame_28 = function() {
		this.ikNode_67 = undefined;this.ikNode_71 = undefined;this.ikNode_80 = undefined;this.ikNode_76 = undefined;this.ikNode_83 = undefined;this.ikNode_86 = undefined;this.ikNode_67 = this.Armature_7.ikNode_67;
		this.ikNode_71 = this.Armature_7.ikNode_71;
		this.ikNode_80 = this.Armature_7.ikNode_80;
		this.ikNode_76 = this.Armature_7.ikNode_76;
		this.ikNode_83 = this.Armature_7.ikNode_83;
		this.ikNode_86 = this.Armature_7.ikNode_86;
	}
	this.frame_29 = function() {
		this.ikNode_67 = undefined;this.ikNode_71 = undefined;this.ikNode_80 = undefined;this.ikNode_76 = undefined;this.ikNode_83 = undefined;this.ikNode_86 = undefined;this.ikNode_67 = this.Armature_7.ikNode_67;
		this.ikNode_71 = this.Armature_7.ikNode_71;
		this.ikNode_80 = this.Armature_7.ikNode_80;
		this.ikNode_76 = this.Armature_7.ikNode_76;
		this.ikNode_83 = this.Armature_7.ikNode_83;
		this.ikNode_86 = this.Armature_7.ikNode_86;
	}
	this.frame_30 = function() {
		this.ikNode_67 = undefined;this.ikNode_71 = undefined;this.ikNode_80 = undefined;this.ikNode_76 = undefined;this.ikNode_83 = undefined;this.ikNode_86 = undefined;this.ikNode_67 = this.Armature_7.ikNode_67;
		this.ikNode_71 = this.Armature_7.ikNode_71;
		this.ikNode_80 = this.Armature_7.ikNode_80;
		this.ikNode_76 = this.Armature_7.ikNode_76;
		this.ikNode_83 = this.Armature_7.ikNode_83;
		this.ikNode_86 = this.Armature_7.ikNode_86;
	}
	this.frame_31 = function() {
		this.ikNode_67 = undefined;this.ikNode_71 = undefined;this.ikNode_80 = undefined;this.ikNode_76 = undefined;this.ikNode_83 = undefined;this.ikNode_86 = undefined;this.ikNode_67 = this.Armature_7.ikNode_67;
		this.ikNode_71 = this.Armature_7.ikNode_71;
		this.ikNode_80 = this.Armature_7.ikNode_80;
		this.ikNode_76 = this.Armature_7.ikNode_76;
		this.ikNode_83 = this.Armature_7.ikNode_83;
		this.ikNode_86 = this.Armature_7.ikNode_86;
	}
	this.frame_32 = function() {
		this.ikNode_67 = undefined;this.ikNode_71 = undefined;this.ikNode_80 = undefined;this.ikNode_76 = undefined;this.ikNode_83 = undefined;this.ikNode_86 = undefined;this.ikNode_67 = this.Armature_7.ikNode_67;
		this.ikNode_71 = this.Armature_7.ikNode_71;
		this.ikNode_80 = this.Armature_7.ikNode_80;
		this.ikNode_76 = this.Armature_7.ikNode_76;
		this.ikNode_83 = this.Armature_7.ikNode_83;
		this.ikNode_86 = this.Armature_7.ikNode_86;
	}
	this.frame_33 = function() {
		this.ikNode_67 = undefined;this.ikNode_71 = undefined;this.ikNode_80 = undefined;this.ikNode_76 = undefined;this.ikNode_83 = undefined;this.ikNode_86 = undefined;this.ikNode_67 = this.Armature_7.ikNode_67;
		this.ikNode_71 = this.Armature_7.ikNode_71;
		this.ikNode_80 = this.Armature_7.ikNode_80;
		this.ikNode_76 = this.Armature_7.ikNode_76;
		this.ikNode_83 = this.Armature_7.ikNode_83;
		this.ikNode_86 = this.Armature_7.ikNode_86;
	}
	this.frame_34 = function() {
		this.ikNode_67 = undefined;this.ikNode_71 = undefined;this.ikNode_80 = undefined;this.ikNode_76 = undefined;this.ikNode_83 = undefined;this.ikNode_86 = undefined;this.ikNode_67 = this.Armature_7.ikNode_67;
		this.ikNode_71 = this.Armature_7.ikNode_71;
		this.ikNode_80 = this.Armature_7.ikNode_80;
		this.ikNode_76 = this.Armature_7.ikNode_76;
		this.ikNode_83 = this.Armature_7.ikNode_83;
		this.ikNode_86 = this.Armature_7.ikNode_86;
	}
	this.frame_35 = function() {
		this.ikNode_67 = undefined;this.ikNode_71 = undefined;this.ikNode_80 = undefined;this.ikNode_76 = undefined;this.ikNode_83 = undefined;this.ikNode_86 = undefined;this.ikNode_67 = this.Armature_7.ikNode_67;
		this.ikNode_71 = this.Armature_7.ikNode_71;
		this.ikNode_80 = this.Armature_7.ikNode_80;
		this.ikNode_76 = this.Armature_7.ikNode_76;
		this.ikNode_83 = this.Armature_7.ikNode_83;
		this.ikNode_86 = this.Armature_7.ikNode_86;
	}
	this.frame_36 = function() {
		this.ikNode_67 = undefined;this.ikNode_71 = undefined;this.ikNode_80 = undefined;this.ikNode_76 = undefined;this.ikNode_83 = undefined;this.ikNode_86 = undefined;this.ikNode_67 = this.Armature_7.ikNode_67;
		this.ikNode_71 = this.Armature_7.ikNode_71;
		this.ikNode_80 = this.Armature_7.ikNode_80;
		this.ikNode_76 = this.Armature_7.ikNode_76;
		this.ikNode_83 = this.Armature_7.ikNode_83;
		this.ikNode_86 = this.Armature_7.ikNode_86;
	}
	this.frame_37 = function() {
		this.ikNode_67 = undefined;this.ikNode_71 = undefined;this.ikNode_80 = undefined;this.ikNode_76 = undefined;this.ikNode_83 = undefined;this.ikNode_86 = undefined;this.ikNode_67 = this.Armature_7.ikNode_67;
		this.ikNode_71 = this.Armature_7.ikNode_71;
		this.ikNode_80 = this.Armature_7.ikNode_80;
		this.ikNode_76 = this.Armature_7.ikNode_76;
		this.ikNode_83 = this.Armature_7.ikNode_83;
		this.ikNode_86 = this.Armature_7.ikNode_86;
	}
	this.frame_38 = function() {
		this.ikNode_67 = undefined;this.ikNode_71 = undefined;this.ikNode_80 = undefined;this.ikNode_76 = undefined;this.ikNode_83 = undefined;this.ikNode_86 = undefined;this.ikNode_67 = this.Armature_7.ikNode_67;
		this.ikNode_71 = this.Armature_7.ikNode_71;
		this.ikNode_80 = this.Armature_7.ikNode_80;
		this.ikNode_76 = this.Armature_7.ikNode_76;
		this.ikNode_83 = this.Armature_7.ikNode_83;
		this.ikNode_86 = this.Armature_7.ikNode_86;
	}
	this.frame_39 = function() {
		this.ikNode_67 = undefined;this.ikNode_71 = undefined;this.ikNode_80 = undefined;this.ikNode_76 = undefined;this.ikNode_83 = undefined;this.ikNode_86 = undefined;this.ikNode_67 = this.Armature_7.ikNode_67;
		this.ikNode_71 = this.Armature_7.ikNode_71;
		this.ikNode_80 = this.Armature_7.ikNode_80;
		this.ikNode_76 = this.Armature_7.ikNode_76;
		this.ikNode_83 = this.Armature_7.ikNode_83;
		this.ikNode_86 = this.Armature_7.ikNode_86;
	}
	this.frame_40 = function() {
		this.ikNode_67 = undefined;this.ikNode_71 = undefined;this.ikNode_80 = undefined;this.ikNode_76 = undefined;this.ikNode_83 = undefined;this.ikNode_86 = undefined;this.ikNode_67 = this.Armature_7.ikNode_67;
		this.ikNode_71 = this.Armature_7.ikNode_71;
		this.ikNode_80 = this.Armature_7.ikNode_80;
		this.ikNode_76 = this.Armature_7.ikNode_76;
		this.ikNode_83 = this.Armature_7.ikNode_83;
		this.ikNode_86 = this.Armature_7.ikNode_86;
	}
	this.frame_41 = function() {
		this.ikNode_67 = undefined;this.ikNode_71 = undefined;this.ikNode_80 = undefined;this.ikNode_76 = undefined;this.ikNode_83 = undefined;this.ikNode_86 = undefined;this.ikNode_67 = this.Armature_7.ikNode_67;
		this.ikNode_71 = this.Armature_7.ikNode_71;
		this.ikNode_80 = this.Armature_7.ikNode_80;
		this.ikNode_76 = this.Armature_7.ikNode_76;
		this.ikNode_83 = this.Armature_7.ikNode_83;
		this.ikNode_86 = this.Armature_7.ikNode_86;
	}
	this.frame_42 = function() {
		this.ikNode_67 = undefined;this.ikNode_71 = undefined;this.ikNode_80 = undefined;this.ikNode_76 = undefined;this.ikNode_83 = undefined;this.ikNode_86 = undefined;this.ikNode_67 = this.Armature_7.ikNode_67;
		this.ikNode_71 = this.Armature_7.ikNode_71;
		this.ikNode_80 = this.Armature_7.ikNode_80;
		this.ikNode_76 = this.Armature_7.ikNode_76;
		this.ikNode_83 = this.Armature_7.ikNode_83;
		this.ikNode_86 = this.Armature_7.ikNode_86;
	}
	this.frame_43 = function() {
		this.ikNode_67 = undefined;this.ikNode_71 = undefined;this.ikNode_80 = undefined;this.ikNode_76 = undefined;this.ikNode_83 = undefined;this.ikNode_86 = undefined;this.ikNode_67 = this.Armature_7.ikNode_67;
		this.ikNode_71 = this.Armature_7.ikNode_71;
		this.ikNode_80 = this.Armature_7.ikNode_80;
		this.ikNode_76 = this.Armature_7.ikNode_76;
		this.ikNode_83 = this.Armature_7.ikNode_83;
		this.ikNode_86 = this.Armature_7.ikNode_86;
	}
	this.frame_44 = function() {
		this.ikNode_67 = undefined;this.ikNode_71 = undefined;this.ikNode_80 = undefined;this.ikNode_76 = undefined;this.ikNode_83 = undefined;this.ikNode_86 = undefined;this.ikNode_67 = this.Armature_7.ikNode_67;
		this.ikNode_71 = this.Armature_7.ikNode_71;
		this.ikNode_80 = this.Armature_7.ikNode_80;
		this.ikNode_76 = this.Armature_7.ikNode_76;
		this.ikNode_83 = this.Armature_7.ikNode_83;
		this.ikNode_86 = this.Armature_7.ikNode_86;
	}
	this.frame_45 = function() {
		this.ikNode_67 = undefined;this.ikNode_71 = undefined;this.ikNode_80 = undefined;this.ikNode_76 = undefined;this.ikNode_83 = undefined;this.ikNode_86 = undefined;this.ikNode_67 = this.Armature_7.ikNode_67;
		this.ikNode_71 = this.Armature_7.ikNode_71;
		this.ikNode_80 = this.Armature_7.ikNode_80;
		this.ikNode_76 = this.Armature_7.ikNode_76;
		this.ikNode_83 = this.Armature_7.ikNode_83;
		this.ikNode_86 = this.Armature_7.ikNode_86;
	}
	this.frame_46 = function() {
		this.ikNode_67 = undefined;this.ikNode_71 = undefined;this.ikNode_80 = undefined;this.ikNode_76 = undefined;this.ikNode_83 = undefined;this.ikNode_86 = undefined;this.ikNode_67 = this.Armature_7.ikNode_67;
		this.ikNode_71 = this.Armature_7.ikNode_71;
		this.ikNode_80 = this.Armature_7.ikNode_80;
		this.ikNode_76 = this.Armature_7.ikNode_76;
		this.ikNode_83 = this.Armature_7.ikNode_83;
		this.ikNode_86 = this.Armature_7.ikNode_86;
	}
	this.frame_47 = function() {
		this.ikNode_67 = undefined;this.ikNode_71 = undefined;this.ikNode_80 = undefined;this.ikNode_76 = undefined;this.ikNode_83 = undefined;this.ikNode_86 = undefined;this.ikNode_67 = this.Armature_7.ikNode_67;
		this.ikNode_71 = this.Armature_7.ikNode_71;
		this.ikNode_80 = this.Armature_7.ikNode_80;
		this.ikNode_76 = this.Armature_7.ikNode_76;
		this.ikNode_83 = this.Armature_7.ikNode_83;
		this.ikNode_86 = this.Armature_7.ikNode_86;
	}
	this.frame_48 = function() {
		this.ikNode_67 = undefined;this.ikNode_71 = undefined;this.ikNode_80 = undefined;this.ikNode_76 = undefined;this.ikNode_83 = undefined;this.ikNode_86 = undefined;this.ikNode_67 = this.Armature_7.ikNode_67;
		this.ikNode_71 = this.Armature_7.ikNode_71;
		this.ikNode_80 = this.Armature_7.ikNode_80;
		this.ikNode_76 = this.Armature_7.ikNode_76;
		this.ikNode_83 = this.Armature_7.ikNode_83;
		this.ikNode_86 = this.Armature_7.ikNode_86;
	}
	this.frame_49 = function() {
		this.ikNode_67 = undefined;this.ikNode_71 = undefined;this.ikNode_80 = undefined;this.ikNode_76 = undefined;this.ikNode_83 = undefined;this.ikNode_86 = undefined;this.ikNode_67 = this.Armature_7.ikNode_67;
		this.ikNode_71 = this.Armature_7.ikNode_71;
		this.ikNode_80 = this.Armature_7.ikNode_80;
		this.ikNode_76 = this.Armature_7.ikNode_76;
		this.ikNode_83 = this.Armature_7.ikNode_83;
		this.ikNode_86 = this.Armature_7.ikNode_86;
		this.___loopingOver___ = true;
		this.gotoAndPlay("Stationary");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1).call(this.frame_7).wait(1).call(this.frame_8).wait(1).call(this.frame_9).wait(1).call(this.frame_10).wait(1).call(this.frame_11).wait(1).call(this.frame_12).wait(1).call(this.frame_13).wait(1).call(this.frame_14).wait(1).call(this.frame_15).wait(1).call(this.frame_16).wait(1).call(this.frame_17).wait(1).call(this.frame_18).wait(1).call(this.frame_19).wait(1).call(this.frame_20).wait(1).call(this.frame_21).wait(1).call(this.frame_22).wait(1).call(this.frame_23).wait(1).call(this.frame_24).wait(1).call(this.frame_25).wait(1).call(this.frame_26).wait(1).call(this.frame_27).wait(1).call(this.frame_28).wait(1).call(this.frame_29).wait(1).call(this.frame_30).wait(1).call(this.frame_31).wait(1).call(this.frame_32).wait(1).call(this.frame_33).wait(1).call(this.frame_34).wait(1).call(this.frame_35).wait(1).call(this.frame_36).wait(1).call(this.frame_37).wait(1).call(this.frame_38).wait(1).call(this.frame_39).wait(1).call(this.frame_40).wait(1).call(this.frame_41).wait(1).call(this.frame_42).wait(1).call(this.frame_43).wait(1).call(this.frame_44).wait(1).call(this.frame_45).wait(1).call(this.frame_46).wait(1).call(this.frame_47).wait(1).call(this.frame_48).wait(1).call(this.frame_49).wait(1));

	// Armature_7_obj_
	this.Armature_7 = new lib.Rhino_Armature_7();
	this.Armature_7.name = "Armature_7";
	this.Armature_7.parent = this;
	this.Armature_7.setTransform(276.7,205.2,1,1,0,0,0,276.7,205.2);
	this.Armature_7.depth = 0;
	this.Armature_7.isAttachedToCamera = 0
	this.Armature_7.isAttachedToMask = 0
	this.Armature_7.layerDepth = 0
	this.Armature_7.layerIndex = 0
	this.Armature_7.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Armature_7).wait(50));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(39.8,-38.1,442.09999999999997,469.20000000000005);


(lib.Scene_1_Rhino = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Rhino
	this.rhino_mc = new lib.Rhino_1();
	this.rhino_mc.name = "rhino_mc";
	this.rhino_mc.parent = this;
	this.rhino_mc.setTransform(-197.5,274.1,1,1,0,0,0,236.3,206.5);

	this.timeline.addTween(cjs.Tween.get(this.rhino_mc).to({x:450.65,y:260.6},69).wait(1).to({x:1166.95},59).wait(1));

}).prototype = p = new cjs.MovieClip();


// stage content:
(lib.Rhino = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	this.___GetDepth___ = function(obj) {
		var depth = obj.depth;
		var cameraObj = this.___camera___instance;
		if(cameraObj && cameraObj.depth && obj.isAttachedToCamera)
		{
			depth += depth + cameraObj.depth;
		}
		return depth;
		}
	this.___needSorting___ = function() {
		for (var i = 0; i < this.getNumChildren() - 1; i++)
		{
			var prevDepth = this.___GetDepth___(this.getChildAt(i));
			var nextDepth = this.___GetDepth___(this.getChildAt(i + 1));
			if (prevDepth < nextDepth)
				return true;
		}
		return false;
	}
	this.___sortFunction___ = function(obj1, obj2) {
		return (this.exportRoot.___GetDepth___(obj2) - this.exportRoot.___GetDepth___(obj1));
	}
	this.on('tick', function (event){
		var curTimeline = event.currentTarget;
		if (curTimeline.___needSorting___()){
			this.sortChildren(curTimeline.___sortFunction___);
		}
	});

	// timeline functions:
	this.frame_0 = function() {
		this.rhino_mc = this.Rhino.rhino_mc;
		this.play_btn = this.Btn.play_btn;
	}
	this.frame_14 = function() {
		this.play_btn = undefined;this.play_btn = this.Btn.play_btn;
	}
	this.frame_69 = function() {
		this.rhino_mc = undefined;this.rhino_mc = this.Rhino.rhino_mc;
		this.stop();
		this.rhino_mc.gotoAndPlay("Stationary");
	}
	this.frame_70 = function() {
		this.play_btn = undefined;this.rhino_mc = undefined;this.rhino_mc = this.Rhino.rhino_mc;
	}
	this.frame_129 = function() {
		this.rhino_mc = undefined;this.rhino_mc = this.Rhino.rhino_mc;
		this.___loopingOver___ = true;
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(14).call(this.frame_14).wait(55).call(this.frame_69).wait(1).call(this.frame_70).wait(59).call(this.frame_129).wait(1));

	// Rhino_obj_
	this.Rhino = new lib.Scene_1_Rhino();
	this.Rhino.name = "Rhino";
	this.Rhino.parent = this;
	this.Rhino.setTransform(-157.2,272.8,1,1,0,0,0,-157.2,272.8);
	this.Rhino.depth = 0;
	this.Rhino.isAttachedToCamera = 0
	this.Rhino.isAttachedToMask = 0
	this.Rhino.layerDepth = 0
	this.Rhino.layerIndex = 0
	this.Rhino.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Rhino).wait(130));

	// Btn_obj_
	this.Btn = new lib.Scene_1_Btn();
	this.Btn.name = "Btn";
	this.Btn.parent = this;
	this.Btn.setTransform(497.2,701,1,1,0,0,0,497.2,701);
	this.Btn.depth = 0;
	this.Btn.isAttachedToCamera = 0
	this.Btn.isAttachedToMask = 0
	this.Btn.layerDepth = 0
	this.Btn.layerIndex = 1
	this.Btn.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Btn).wait(70).to({_off:true},1).wait(59));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(163.3,355.9,1203.7,402.4);
// library properties:
lib.properties = {
	id: 'F67AF913B7324C5E921F85667DB56F67',
	width: 960,
	height: 640,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/rhino_atlas_.png", id:"rhino_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['F67AF913B7324C5E921F85667DB56F67'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


// Layer depth API : 

AdobeAn.Layer = new function() {
	this.getLayerZDepth = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth; else 0;";
		return eval(script);
	}
	this.setLayerZDepth = function(timeline, layerName, zDepth)
	{
		const MAX_zDepth = 10000;
		const MIN_zDepth = -5000;
		if(zDepth > MAX_zDepth)
			zDepth = MAX_zDepth;
		else if(zDepth < MIN_zDepth)
			zDepth = MIN_zDepth;
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth = " + zDepth + ";";
		eval(script);
	}
	this.removeLayer = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline.removeChild(timeline." + layerName + ");";
		eval(script);
	}
	this.addNewLayer = function(timeline, layerName, zDepth)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		zDepth = typeof zDepth !== 'undefined' ? zDepth : 0;
		var layer = new createjs.MovieClip();
		layer.name = layerName;
		layer.depth = zDepth;
		layer.layerIndex = 0;
		timeline.addChild(layer);
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;