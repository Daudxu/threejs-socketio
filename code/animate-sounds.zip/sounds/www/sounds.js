(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.startBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.text = new cjs.Text("Start", "25px 'Arial Narrow'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 31;
	this.text.lineWidth = 142;
	this.text.parent = this;
	this.text.setTransform(69.95,5);

	this.timeline.addTween(cjs.Tween.get(this.text).to({_off:true},3).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0066FF").s().p("AqsC+IAAl7IVZAAIAAF7g");
	this.shape.setTransform(68.5,19);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#32A2FF").s().p("AqsC+IAAl7IVZAAIAAF7g");
	this.shape_1.setTransform(68.5,19);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3,0,146,38);


(lib.sfxBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.text = new cjs.Text("Sfx", "25px 'Arial Narrow'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 31;
	this.text.lineWidth = 142;
	this.text.parent = this;
	this.text.setTransform(69.95,5);

	this.timeline.addTween(cjs.Tween.get(this.text).to({_off:true},3).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0066FF").s().p("AqsC+IAAl7IVZAAIAAF7g");
	this.shape.setTransform(68.5,19);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#32A2FF").s().p("AqsC+IAAl7IVZAAIAAF7g");
	this.shape_1.setTransform(68.5,19);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3,0,146,38);


(lib.ball_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00CC99").s().p("AjCC/QhQhPAAhwQAAhvBQhPQBRhPBxAAQByAABRBPQBQBPAABvQAABwhQBPQhRBPhyAAQhxAAhRhPg");
	this.shape.setTransform(0.5,1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3));

}).prototype = p = new cjs.MovieClip();


(lib.ball = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.incX = 20;
	}
	this.frame_2 = function() {
		this.___loopingOver___ = true;
		this.x += this.incX;
		
		console.log( `ball.x=${this.x} incX=${this.incX} currentFrame=${this.currentFrame}`);
		
		if (this.incX>0){
			if (this.x>620){
				this.incX = -this.incX;
				playSound('bounce', 0);
			}
		}else{
			if (this.x<20){
				this.incX = -this.incX;
				playSound('bounce', 0);
			}
		}
		
		this.gotoAndPlay(this.currentFrame-1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2).call(this.frame_2).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.ball_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(0.5,1,1,1,0,0,0,0.5,1);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27,-26,55,54);


(lib.Scene_1_Layer_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.start_btn = new lib.startBtn();
	this.start_btn.name = "start_btn";
	this.start_btn.parent = this;
	this.start_btn.setTransform(317.45,417,1,1,0,0,0,68.5,19);
	new cjs.ButtonHelper(this.start_btn, 0, 1, 2, false, new lib.startBtn(), 3);

	this.instance = new lib.ball();
	this.instance.parent = this;
	this.instance.setTransform(354.5,264.05,1,1,0,0,0,27.5,27);

	this.sfx_btn = new lib.sfxBtn();
	this.sfx_btn.name = "sfx_btn";
	this.sfx_btn.parent = this;
	this.sfx_btn.setTransform(325.45,427,1,1,0,0,0,68.5,19);
	new cjs.ButtonHelper(this.sfx_btn, 0, 1, 2, false, new lib.sfxBtn(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.start_btn}]}).to({state:[{t:this.sfx_btn},{t:this.instance}]},4).to({state:[]},25).wait(1));

}).prototype = p = new cjs.MovieClip();


// stage content:
(lib.sounds = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"start-music":4});

	this.___GetDepth___ = function(obj) {
		var depth = obj.depth;
		var cameraObj = this.___camera___instance;
		if(cameraObj && cameraObj.depth && obj.isAttachedToCamera)
		{
			depth += depth + cameraObj.depth;
		}
		return depth;
		}
	this.___needSorting___ = function() {
		for (var i = 0; i < this.getNumChildren() - 1; i++)
		{
			var prevDepth = this.___GetDepth___(this.getChildAt(i));
			var nextDepth = this.___GetDepth___(this.getChildAt(i + 1));
			if (prevDepth < nextDepth)
				return true;
		}
		return false;
	}
	this.___sortFunction___ = function(obj1, obj2) {
		return (this.exportRoot.___GetDepth___(obj2) - this.exportRoot.___GetDepth___(obj1));
	}
	this.on('tick', function (event){
		var curTimeline = event.currentTarget;
		if (curTimeline.___needSorting___()){
			this.sortChildren(curTimeline.___sortFunction___);
		}
	});

	// timeline functions:
	this.frame_0 = function() {
		this.start_btn = this.Layer_2.start_btn;
		this.stop();
		
		const self = this;
		
		this.start_btn.on('click', function(){
			self.gotoAndPlay('start-music');
		});
	}
	this.frame_4 = function() {
		this.start_btn = undefined;this.sfx_btn = this.Layer_2.sfx_btn;
		this.sfx_btn.on('click', function(){
			playSound('hit', 0);
		});
		
		this.stop();
		playSound("music",-1);
	}
	this.frame_29 = function() {
		this.sfx_btn = undefined;this.___loopingOver___ = true;
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4).call(this.frame_4).wait(25).call(this.frame_29).wait(1));

	// Layer_2_obj_
	this.Layer_2 = new lib.Scene_1_Layer_2();
	this.Layer_2.name = "Layer_2";
	this.Layer_2.parent = this;
	this.Layer_2.setTransform(318.9,417,1,1,0,0,0,318.9,417);
	this.Layer_2.depth = 0;
	this.Layer_2.isAttachedToCamera = 0
	this.Layer_2.isAttachedToMask = 0
	this.Layer_2.layerDepth = 0
	this.Layer_2.layerIndex = 0
	this.Layer_2.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_2).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,399.9,446);
// library properties:
lib.properties = {
	id: 'F9AC489E69A448B28EBAE0253822FC23',
	width: 640,
	height: 480,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"sounds/bounce.mp3", id:"bounce"},
		{src:"sounds/hit.mp3", id:"hit"},
		{src:"sounds/music.mp3", id:"music"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['F9AC489E69A448B28EBAE0253822FC23'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


// Layer depth API : 

AdobeAn.Layer = new function() {
	this.getLayerZDepth = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth; else 0;";
		return eval(script);
	}
	this.setLayerZDepth = function(timeline, layerName, zDepth)
	{
		const MAX_zDepth = 10000;
		const MIN_zDepth = -5000;
		if(zDepth > MAX_zDepth)
			zDepth = MAX_zDepth;
		else if(zDepth < MIN_zDepth)
			zDepth = MIN_zDepth;
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth = " + zDepth + ";";
		eval(script);
	}
	this.removeLayer = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline.removeChild(timeline." + layerName + ");";
		eval(script);
	}
	this.addNewLayer = function(timeline, layerName, zDepth)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		zDepth = typeof zDepth !== 'undefined' ? zDepth : 0;
		var layer = new createjs.MovieClip();
		layer.name = layerName;
		layer.depth = zDepth;
		layer.layerIndex = 0;
		timeline.addChild(layer);
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;